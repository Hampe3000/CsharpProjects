﻿using System;

namespace HelloWorld_
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.ReadLine();
            Console.WriteLine("Hope you are well.");
            Console.ReadLine();
            }
    }
}
