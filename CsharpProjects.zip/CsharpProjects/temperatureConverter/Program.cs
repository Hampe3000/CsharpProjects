﻿using System;

namespace A2B
{
    class temperatureConverter
    {
        static void Main(string[] args)
        {
            string choisetxt = string.Empty;//setup
            int choise = 0;
            bool exit = false;

            do
            {
                //cool menu
                Console.WriteLine();
                Console.WriteLine("+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+");
                Console.WriteLine();
                Console.WriteLine("Welcome to the temperature converter please select one of the folowing:");
                Console.WriteLine();
                Console.WriteLine("+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+");
                Console.WriteLine();
                Console.WriteLine("Celsius to Fahrenheit   :  1");
                Console.WriteLine();
                Console.WriteLine("Fahrenheit to Celsius   :  2");
                Console.WriteLine();
                Console.WriteLine("Exit                    :  0");
                Console.WriteLine();
                Console.WriteLine("+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+");
                Console.WriteLine();

                choisetxt = Console.ReadLine();//Record user input
                bool goodChoise = int.TryParse(choisetxt, out choise);
                if (goodChoise == false || choise < 0 || choise > 3)//maybe change back to 0
                {
                    Console.WriteLine("Please enter a valid option");//invalid user input
                }
                else
                {
                    if (choise == 1) //run the celsius to fahrenheit methode
                    {
                        cToF();
                    }
                    if (choise == 2) //run the fahrenheit to cesius methode 
                    {
                        fToC();
                    }
                    if (choise == 0) //exit the program
                    {
                        exit = true;
                        Console.WriteLine("Okay. Have a nice day!");
                    }
                }
            } while (!exit);

            void cToF()
            {
                string Ctxt = string.Empty;
                double C = 0.0;//setup
                double k = 32.0;
                double m = 1.8;
                double F = 0.0;
                bool finish = false;

                Console.WriteLine("You have chosen to convert Celsius to Fahreheit");
                Console.WriteLine();

                do
                {
                    Console.WriteLine("Please enter the temperature you would like to convert or type E+Enter to exit");
                    Ctxt = Console.ReadLine();
                    bool go = double.TryParse(Ctxt, out C);//convert
                    Ctxt = Ctxt.Trim();//check if exit
                    char input = Ctxt[0];

                    if ((input == 'E') || (input == 'e'))
                    {
                        finish = true;//exit
                    }
                    else //continue
                    {
                        if (!go)//invalid input
                        {
                            Console.WriteLine("Please enter a valid input");
                        }
                        else //good input
                        {
                            F = C * m + k;//calculate

                            Console.WriteLine(C+" degrees Celsius is equivalent to "+F+" degrees Fahrenheit.");//display result
                            Console.WriteLine();
                        }
                    }
                } while (!finish);


            }
            void fToC()
            {
                string Ftxt = string.Empty;
                double C = 0.0;//setup
                double k = 32.0;
                double m = 1.8;
                double F = 0.0;
                bool finish = false;

                Console.WriteLine("You have chosen to convert Fahrenheit to Celsius");
                Console.WriteLine();

                do
                {
                    Console.WriteLine("Please enter the temperature you would like to convert or type E+Enter to exit");
                    Ftxt = Console.ReadLine();
                    bool go = double.TryParse(Ftxt, out F);//convert
                    Ftxt = Ftxt.Trim();//check if exit
                    char input = Ftxt[0];

                    if ((input == 'E') || (input == 'e'))
                    {
                        finish = true;//exit
                    }
                    else //continue
                    {
                        if (!go)//invalid input
                        {
                            Console.WriteLine("Please enter a valid input");
                        }
                        else //good input
                        {
                            C = (F - k) / m;//calculate

                            Console.WriteLine(F + " degrees Fahrenheit is equivalent to " + C + " degrees Celsius.");
                            Console.WriteLine();
                        }
                    }
                } while (!finish);
            }

        }
    }
}
