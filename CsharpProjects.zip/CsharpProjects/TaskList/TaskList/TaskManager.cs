﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaskList
{
    class TaskManager
    {
        private List<Task> tasks;

        public TaskManager() //the constructor creates a new list of tasks
        {
            tasks = new List<Task>();
        }

        public bool AddTask(Task task) //method to add a task to the list
        {
            bool ok = true;
            if (task != null)
            {
                tasks.Add(task);
            }
            else 
            {
                ok = false;
            }
            return ok;
        }

        public void ChangeTaskAt(Task task, int index) //edits an existing task
        {
            tasks[index] = task;
        }

        public void DeleteAt(int index) //removes a task
        {
            tasks.RemoveAt(index);
        }

        public string[] GetTasksInfo() //used to send the task list to the gui
        {
            string[] myInfo;
            if (tasks.Count <= 0)
            {
                return null;
            }
            myInfo = new string[tasks.Count];
            for (int i = 0; i < tasks.Count; i++) 
            {
                myInfo[i] = tasks[i].ToString();
            }
            return myInfo;
        }

        public Task GetTaskAt(int index) //used to access info about the participant
        {
            return tasks[index];
        }

        public bool ReadFile(string filename) //reads data from a saved file
        {
            FileManager fileManager = new FileManager();

            return fileManager.ReadTaskList(tasks, filename);
        }

        public bool WriteFile(string filename) 
        {
            FileManager fileManager = new FileManager();

            return fileManager.SaveTaskList(tasks, filename);
        }
    }
}
