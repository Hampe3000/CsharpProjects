﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaskList
{
    enum PriorityType
    {
        Very_Important,
        Important,
        Normal,
        Less_Important,
        Not_Important
    }
}
