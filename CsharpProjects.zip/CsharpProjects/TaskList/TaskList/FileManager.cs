﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace TaskList
{
    class FileManager
    {
        private const string fileVersionToken = "token"; //the fileversiontoken
        private const double fileVersionNR = 1.0; //the fileversion nr

        public bool SaveTaskList(List<Task> tasks, string fileName) //used to save the task list
        {
            bool ok = true;
            StreamWriter writer = null;
            try
            {
                writer = new StreamWriter(fileName);
                writer.WriteLine(fileVersionToken);
                writer.WriteLine(fileVersionNR);
                writer.WriteLine(tasks.Count);
                for (int i = 0; i < tasks.Count; i++)
                {
                    writer.WriteLine(tasks[i].GetDescription());
                    writer.WriteLine(tasks[i].GetPriorityString());
                    writer.WriteLine(tasks[i].GetDateAndTime());
                }
            }
            catch
            {
                ok = false;
            }
            finally 
            {
                if (writer != null)
                    writer.Close();
            }
            return ok;
        }

        public bool ReadTaskList(List<Task> tasks, string fileName) 
        {
            bool ok = true;
            StreamReader reader = null;

            try
            {
                if (tasks != null)
                    tasks.Clear();
                else
                    tasks = new List<Task>();

                reader = new StreamReader(fileName);

                string versionTest = reader.ReadLine();
                double version = double.Parse(reader.ReadLine());

                if (versionTest == fileVersionToken && version == fileVersionNR)
                {
                    int count = int.Parse(reader.ReadLine());
                    for (int i = 0; i < count; i++)
                    {
                        Task task = new Task();
                        task.SetDescription(reader.ReadLine());
                        task.SetPriority((PriorityType)Enum.Parse(typeof(PriorityType), reader.ReadLine()));
                        task.SetDateAndTime(DateTime.Parse(reader.ReadLine()));

                        tasks.Add(task);
                    }
                }
                else
                {
                    ok = false;
                }
            }
            catch
            {
                ok = false;
            }
            finally 
            {
                if (reader != null)
                    reader.Close();
            }
            return ok;
        }
    }
}
