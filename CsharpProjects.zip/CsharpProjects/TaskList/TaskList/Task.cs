﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaskList
{
    class Task
    {
        //The different variables a task consists of
        private DateTime date;
        private string description;
        private PriorityType priority;

        public Task() : this(DateTime.Now, "No description", PriorityType.Normal) //default constructor
        {

        }

        public Task(DateTime date, string description, PriorityType priority) //the constructor that handles input when all fields have assigned values
        {
            this.date = date;
            this.description = description;
            this.priority = priority;
        }

        public string GetPriorityString() //replaces potential _ of priority types with a blank space
        {
            string strPriority = priority.ToString();
            strPriority = strPriority.Replace('_', ' ');
            return strPriority;
        }

        private string GetTimeString() //formats the time part of the date
        {
            string time = date.Hour.ToString() +':'+ date.Minute.ToString();
            return time;
        }

        public override string ToString() //formats all of the tasks details into one string
        {
            string taskDetails = String.Format("{0, -20} {1, 10} {2, -16} {3, -20}", date.ToLongDateString(), GetTimeString(), GetPriorityString(), description);
            return taskDetails;
        }

        //getters and setters
        public DateTime GetDateAndTime() 
        {
            return date;
        }
        public void SetDateAndTime(DateTime value) 
        {
            date = value;
        }
        public string GetDescription() 
        {
            return description;
        }
        public void SetDescription(string value) 
        {
            description = value;
        }
        public PriorityType GetPriority() 
        {
            return priority;
        }
        public void SetPriority(PriorityType value) 
        {
            priority = value;
        }
        public DateTime GetTaskDate() 
        {
            return date;
        }
        public void SetTaskDate(DateTime value) 
        {
            date = value;
        }
    }
}
