﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TaskList
{
    public partial class MainForm : Form
    {
        private TaskManager taskManager; //declared but not created

        private string fileName = Application.StartupPath + "\\Tasks.txt"; //filename for saving and reading

        public MainForm() //deffault constructor
        {
            InitializeComponent();

            InitializeGUI();
        }

        private void InitializeGUI() //initializes/resets the gui
        {
            this.Text = "TaskList by Hampus Oxenholt";

            taskManager = new TaskManager();

            //cbxPriority.Items.Clear();
            //cbxPriority.Items.AddRange(Enum.GetNames(typeof(PriorityType)));
            cbxPriority.DataSource = Enum.GetValues(typeof(PriorityType));
            cbxPriority.SelectedItem = null;
            txtDescription.Text = string.Empty;

            dtpDateTime.Format = DateTimePickerFormat.Custom;
            dtpDateTime.CustomFormat = "yyyy-MM-dd  HH:mm";

            toolTip1.ShowAlways = true;

            toolTip1.SetToolTip(dtpDateTime, "Click to Open Calander for date and write time here");
            toolTip1.SetToolTip(cbxPriority, "Select the priority");

            string tips = "To change: please select an item first." + Environment.NewLine;
            tips += "Make your changes in the input controls." + Environment.NewLine;
            tips += "Click the Change button." + Environment.NewLine;

            toolTip1.SetToolTip(lbxTasks, tips);
            toolTip1.SetToolTip(btnChange, tips);

            toolTip1.SetToolTip(btnDelete, "Select an item to unlock this button");

            toolTip1.SetToolTip(txtDescription, "Give me a task!");

            lbxTasks.Items.Clear();
            Menu();
            DisableButtons();
            ClearInput();
        }

        private void clockTimer_Tick(object sender, EventArgs e) //updates the clock
        {
            lblClock.Text = DateTime.Now.ToLongTimeString();
        }

        private void btnAdd_Click(object sender, EventArgs e) //adds a task
        {
            if (ValidateInput())//checks that the input is valid before adding the task
            { 
                Task task = new Task(dtpDateTime.Value, txtDescription.Text, (PriorityType)cbxPriority.SelectedItem);
                taskManager.AddTask(task);
                DisableButtons();
                UpdateGUI();
            }
        }

        private void DisableButtons() //disables the change and delete buttons
        {
            btnChange.Enabled = false;
            btnDelete.Enabled = false;
        }

        private bool ValidateInput() //checks so the user has selected a priority and filed in a description
        {
            bool ok = false;
            if (cbxPriority.SelectedIndex > -1)//checks that priority is selected
            {
                if (txtDescription.Text != string.Empty)//cheks that the user wrote a description
                {
                    ok = true;
                }
                else
                {
                    MessageBox.Show("Please make your life easier by providing us with a description!");//error message
                }
            }
            else 
            {
                MessageBox.Show("Please select a priority before clicking the add button");//error message
            }
            
            return ok;
        }

        private void UpdateGUI() //Update the guis list and clears input controls
        {
            lbxTasks.Items.Clear();//update the listbox
            string[] Guestlist = taskManager.GetTasksInfo();
            if (Guestlist != null)
            {
                for (int i = 0; i < Guestlist.Length; i++)
                {
                    string str = $"{Guestlist[i]}";
                    lbxTasks.Items.Add(str);
                }
            }

            ClearInput();//clears the input controls
        }

        private void ClearInput() //clears the input controls
        {
            txtDescription.Text = string.Empty;
            cbxPriority.SelectedItem = null;
            //dtpDateTime.Value = DateTime.MinValue;
        }

        private void lbxTasks_SelectedIndexChanged(object sender, EventArgs e) //selects task from the list
        {
            int index = IsListBoxItemSelected();
            if (index >= 0)
            {
                Task selectedTask = taskManager.GetTaskAt(index); //loads the task
                dtpDateTime.Value = selectedTask.GetDateAndTime();
                cbxPriority.SelectedItem = selectedTask.GetPriority();
                txtDescription.Text = selectedTask.GetDescription();

                btnChange.Enabled = true; //enables the change and delete buttons
                btnDelete.Enabled = true;
            }
        }

        private int IsListBoxItemSelected() //checks the index of the selected task
        {
            int index = lbxTasks.SelectedIndex;
            return index;
        }

        private void btnChange_Click(object sender, EventArgs e)//edits a task
        {
            int index = IsListBoxItemSelected();
            Task taskIn = new Task(dtpDateTime.Value, txtDescription.Text, (PriorityType)cbxPriority.SelectedItem);
            taskManager.ChangeTaskAt(taskIn, index);
            DisableButtons();
            UpdateGUI();
        }

        private void btnDelete_Click(object sender, EventArgs e) //deletes a task
        {
            int index = IsListBoxItemSelected();
            taskManager.DeleteAt(index);
            DisableButtons();
            UpdateGUI();
        }

        private void Menu() //creates the menu 
        {
            MenuStrip menu = new MenuStrip();

            ToolStripMenuItem windowMenu = new ToolStripMenuItem("File"); //creates the submenu "File"

            ToolStripMenuItem windowNewMenu = new ToolStripMenuItem("New", null, new EventHandler(windowNewMenu_Click)); //creates the different menu items
            ToolStripMenuItem windowSaveMenu = new ToolStripMenuItem("Save", null, new EventHandler(windowSaveMenu_Click));
            ToolStripMenuItem windowLoadMenu = new ToolStripMenuItem("Load", null, new EventHandler(windowLoadMenu_Click));
            ToolStripMenuItem windowExitMenu = new ToolStripMenuItem("Exit", null, new EventHandler(windowExitMenu_Click));

            windowMenu.DropDownItems.Add(windowNewMenu); //adds the items to the "File" submenu
            windowMenu.DropDownItems.Add(windowSaveMenu);
            windowMenu.DropDownItems.Add(windowLoadMenu);
            windowMenu.DropDownItems.Add(windowExitMenu);

            ((ToolStripDropDownMenu)(windowMenu.DropDown)).ShowImageMargin = false;
            ((ToolStripDropDownMenu)(windowMenu.DropDown)).ShowCheckMargin = true;

            menu.MdiWindowListItem = windowMenu; //adds the submenu to the menu
            menu.Items.Add(windowMenu); 

            menu.Dock = DockStyle.Top;  //docks the menu to the top of the form.

            this.MainMenuStrip = menu; //adds the menu to the form
            this.Controls.Add(menu);
        }

        void windowNewMenu_Click(object sender, EventArgs e)//resets/creates a new form 
        {
            InitializeGUI();
        }
        void windowSaveMenu_Click(object sender, EventArgs e)//saves current tasklist to file
        {
            if (taskManager.WriteFile(fileName)) 
            {
                MessageBox.Show("Saved");
            }
        }
        void windowLoadMenu_Click(object sender, EventArgs e)//loads tasklist from file
        {
            taskManager.ReadFile(fileName);
            UpdateGUI();
        }
        void windowExitMenu_Click(object sender, EventArgs e)//terminates the program
        {
            DialogResult dlgResult = MessageBox.Show("EXIT!" , "Are you sure you want to?", MessageBoxButtons.OKCancel);
            if (dlgResult == DialogResult.OK) 
            {
                Application.Exit();
            }
        }
    }

    
}
