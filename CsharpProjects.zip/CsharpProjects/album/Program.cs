﻿using System;

namespace album
{
    public class Album
    {
        //Variabler Title, Group, Tracks
        private string title;
        private string group;
        private int tracks;

        static void Main(string[] args)
        {
            //Create object
            Album albumobj = new Album();
            albumobj.Starta();
        }
        public void Starta()
        {
            //Opening lines
            Console.WriteLine("Welcome to the music album organiser.");
            Console.WriteLine("Please fill out the information below.");
            Console.ReadLine();

            ReadAndSaveAlbumData();
            DisplayAlbumInfo();
        }

        //Input
        public void ReadAndSaveAlbumData()
        {
            //title
            Console.WriteLine("Enter the name of the album.");
            title = Console.ReadLine();

            //group
            Console.WriteLine("Enter the name of the group/artist.");
            group = Console.ReadLine();

            //tracks
            Console.WriteLine("Enter the amount of tracks on the album.");
            string textvaluea = Console.ReadLine();
            tracks = int.Parse(textvaluea);
        }

        //Output
        public void DisplayAlbumInfo()
        {
            Console.WriteLine("***************************************************************************************");
            Console.WriteLine(title);   //Display title
            Console.Write("By " + group + " is ");   //Display group and extra info
            if (tracks <= 5)
            {
                Console.WriteLine("a banger of an album with " + tracks + " tracks");
            }
            else
            {
                if (tracks <= 10)
                {
                    Console.WriteLine("a hot album with " + tracks + " tracks");
                }
                else
                {

                    if (tracks == 69)
                    {
                        Console.WriteLine("a nice! album with " + tracks + " tracks");
                    }
                    else
                    {
                        Console.WriteLine("pure fire of an album with " + tracks + " tracks");
                    }
                }
            }

            Console.WriteLine("***************************************************************************************");
            Console.WriteLine("To fill out another album please press enter.");
            Console.ReadLine();
            Starta();//Loop



        }
    }
}
