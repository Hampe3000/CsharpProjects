﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventOrganizer
{
    class Address
    {
        //the different variables this class handles
        private string city;
        private Countries country;
        private string street;
        private string zipCode;

        public Address() : this("no street", "00000", "no city")//the constructor that provides defult values for all variables
        {            
        }

        public Address(Address theOther) : this(theOther.GetStreet(), theOther.GetZipCode(), theOther.GetCity(), theOther.GetCountry())//the copy constructor
        {            
        }

        public Address(string street, string zipCode, string city) : this (street, zipCode, city, Countries.Sweden)//the constructor that has defult value for country
        {
        }
        public Address(string street, string zipCode, string city, Countries country)//the construcor that takes the most arguments
        {
            this.street = street;
            this.zipCode = zipCode;
            this.city = city;
            this.country = country;
        }


        private string GetAddressLabel() //combines street city and zipcode to one string
        {
            return string.Format("{0} {1} {2}", street, city, zipCode);
        }

        private string GetCountrystring() //replaces the _ of some countries with a blank space
        {
            string strCountry = country.ToString();
            strCountry = strCountry.Replace('_', ' ');
            return strCountry;
        }

        public override string ToString() //combines all information to one string
        {
            return string.Format("{0} {1}", GetAddressLabel(), GetCountrystring());
        }

        private bool Validate() //checks so that city isn't empty
        {
            bool ok = false;
            if (!string.IsNullOrEmpty(city)) 
            {
                ok = true;
            }
            return ok;
        }

        //getters & setters
        public string GetCity() 
        {
            return city;
        }
        public void SetCity(string value) 
        {
            city = value;
        }
        public string GetStreet() 
        {
            return street;
        }
        public void SetStreet(string value) 
        {
            street = value;
        }
        public string GetZipCode() 
        {
            return zipCode;
        }
        public void SetZipCode(string value) 
        {
            zipCode = value;
        }
        public Countries GetCountry() 
        {
            return country;
        }
        public void SetCountry(Countries value) 
        {
            country = value;
        }
    }
}
