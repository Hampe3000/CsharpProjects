﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventOrganizer
{
    class ParticipantManager
    {
        private List<Participant> participants;

        public ParticipantManager() 
        {
            participants = new List<Participant>();
        }

        public bool AddParticipant(Participant ParticipantIn) //adds a participant to the list with some defult values
        {
            participants.Add(ParticipantIn);
            return true;
        }

        public bool AddParticipant(string firstName, string lastName, Address address) //adds a participant to the list
        {
            participants.Add(new Participant(firstName, lastName, address));
            return true;
        }

        public bool ChangeParticipantAt(Participant ParticipantIn, int index)//used to edit an existing participant 
        {
            participants[index] = ParticipantIn;
            return true;
        }

        private bool CheckIndex(int index) //never used (could be used in the changeat and removeat methods)
        {
            bool ok = true;
            if (index < 0 || index > (participants.Count - 1)) 
            {
                ok = false;
            }
            return ok;
        }

        public bool DeleteParticipantAt(int index) //deletes the participant at given index
        {
            participants.RemoveAt(index);
            return true;
        }

        public Participant GetParticipantAt(int index) //used to access info about the participant
        {
            return participants[index];
        }

        public string[] GetParticipantsInfo() //used by the gui
        {
            string[] myInfo;
            if (participants.Count <= 0)
            {
                return null;
            }

            myInfo = new string[participants.Count];
            for(int i =0; i < participants.Count; i++) 
            {
                myInfo[i] = participants[i].ToString();
            }
            return myInfo;
        }

        public void TestValues() //unknown function
        {
            
        }

        //getter
        public int GetCount() 
        {
            return participants.Count;
        }
    }
}
