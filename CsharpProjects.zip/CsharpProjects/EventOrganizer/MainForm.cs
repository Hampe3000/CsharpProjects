﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EventOrganizer
{
    public partial class MainForm : Form
    {
        EventManager eventManager; 
        public MainForm()
        {
            InitializeComponent();
            InitializeGUI();
        }

        private void InitializeGUI() // edits the name of the form and disables the add participant groupbox
        {
            Text = "Event Manager by Hampus Oxenholt";
            cbxCountry.DataSource = Enum.GetValues(typeof(Countries));
            cbxCountry.SelectedItem = null;
            gbxParticipant.Enabled = false;
            DisableBUTT();
        }

        private void btnCreate_Click(object sender, EventArgs e)//creates the event
        {
            eventManager = new EventManager();
            bool amountOK = ReadCostPerPerson() && ReadFeesPerPerson();
            if (amountOK)
            {
                eventManager.SetTitle(txtEventName.Text);
                gbxParticipant.Enabled = true;
                UpdateGUI();
            }
        }

        private bool ReadCostPerPerson()
        {
            double costPerPerson = 0.0;
            bool ok = double.TryParse(txtCost.Text, out costPerPerson);
            if (ok)
            {
                eventManager.SetCostPerPerson(costPerPerson);
            }
            else
            {
                MessageBox.Show("invalid input");//error message
                ok = false;
            }
            return ok;
        }
        private bool ReadFeesPerPerson()
        {
            double feesPerPerson = 0.0;
            bool ok = double.TryParse(txtFee.Text, out feesPerPerson);
            if (ok && feesPerPerson >= 0)
            {
                eventManager.SetFeePerPerson(feesPerPerson);
            }
            else
            {
                MessageBox.Show("invalid input");//error message
                ok = false;
            }
            return ok;
        }

        private void btnAdd_Click(object sender, EventArgs e)//adds a participant
        {
           Address address = new Address(txtStreet.Text, txtZip.Text, txtCity.Text, (Countries)cbxCountry.SelectedItem);
           ParticipantManager participantManager = eventManager.GetParticipants();
           participantManager.AddParticipant(txtFirstName.Text, txtLastName.Text, address);
           UpdateGUI();
        }

        private void lbxParticipants_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = IsListBoxItemSelected();
            if (index >= 0)
            {
                ParticipantManager participantManager = eventManager.GetParticipants();
                Participant selectedParticipant = participantManager.GetParticipantAt(index);
                txtFirstName.Text = selectedParticipant.GetFirstName();
                txtLastName.Text = selectedParticipant.GetLastName();
                Address selectedAddress = selectedParticipant.GetAddress();
                txtStreet.Text = selectedAddress.GetStreet();
                txtCity.Text = selectedAddress.GetCity();
                txtZip.Text = selectedAddress.GetZipCode();
                cbxCountry.SelectedItem = selectedAddress.GetCountry();
                
                btnEdit.Enabled = true;
                btnDelete.Enabled = true;
            }


        }

        private void btnDelete_Click(object sender, EventArgs e)//delets the selected participant
        {
            int index = IsListBoxItemSelected();
            ParticipantManager participantManager = eventManager.GetParticipants();
            participantManager.DeleteParticipantAt(index);
            DisableBUTT();
            UpdateGUI();
            ClearTextBoxes();
        }


        private int IsListBoxItemSelected()
        {
            int index = lbxParticipants.SelectedIndex;
            return index;
        }

        private void btnEdit_Click(object sender, EventArgs e)//edits the selected participant
        {
            int index = IsListBoxItemSelected();
            Address address = new Address(txtCity.Text, txtStreet.Text, txtZip.Text, (Countries)cbxCountry.SelectedItem);
            ParticipantManager participantManager = eventManager.GetParticipants();
            Participant participantIn = new Participant(txtFirstName.Text, txtLastName.Text, address);
            participantManager.ChangeParticipantAt(participantIn, index);
            DisableBUTT();
            UpdateGUI();
            ClearTextBoxes();
        }

        private void DisableBUTT()//disables the delete and change button 
        {
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
        }

        private void ClearTextBoxes() //emptys the name input boxes
        {
            txtFirstName.Text = string.Empty;
            txtLastName.Text = string.Empty;
            txtCity.Text = string.Empty;
            txtStreet.Text = string.Empty;
            txtZip.Text = string.Empty;
            cbxCountry.SelectedItem = null;
        }

        private void UpdateGUI() //Update the guis labels and list
        {
            lbxParticipants.Items.Clear();//update the listbox
            ParticipantManager participantManager = eventManager.GetParticipants();
            string[] Guestlist = participantManager.GetParticipantsInfo();
            if (Guestlist != null)
            {
                for (int i = 0; i < Guestlist.Length; i++)
                {
                    string str = $"{Guestlist[i]}";
                    lbxParticipants.Items.Add(str);
                }
            }
           
            double totalCost = eventManager.CalcTotalCost();//update the total cost 
            lblTotalCostValue.Text = totalCost.ToString("0.00");

            double totalFees = eventManager.CalcTotalFees();//updates the total fees 
            lblTotalFeesValue.Text = totalFees.ToString("0.00");

            lblSurplusDeficitValue.Text = (eventManager.CalcTotalCost() - eventManager.CalcTotalFees()).ToString("0.00");//updates the surplus/deficit

            lblNumOfParticipantValue.Text = participantManager.GetCount().ToString();
            ClearTextBoxes();
        }
    }
}
