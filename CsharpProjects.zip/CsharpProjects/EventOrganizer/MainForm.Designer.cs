﻿
namespace EventOrganizer
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbxEvent = new System.Windows.Forms.GroupBox();
            this.btnCreate = new System.Windows.Forms.Button();
            this.txtFee = new System.Windows.Forms.TextBox();
            this.txtCost = new System.Windows.Forms.TextBox();
            this.txtEventName = new System.Windows.Forms.TextBox();
            this.lblFee = new System.Windows.Forms.Label();
            this.lblCost = new System.Windows.Forms.Label();
            this.lblEventName = new System.Windows.Forms.Label();
            this.gbxParticipant = new System.Windows.Forms.GroupBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtStreet = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtZip = new System.Windows.Forms.TextBox();
            this.cbxCountry = new System.Windows.Forms.ComboBox();
            this.lblCountry = new System.Windows.Forms.Label();
            this.lblZip = new System.Windows.Forms.Label();
            this.lblCity = new System.Windows.Forms.Label();
            this.lblStreet = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.gbxEventEconomy = new System.Windows.Forms.GroupBox();
            this.lblSurplusDeficitValue = new System.Windows.Forms.Label();
            this.lblTotalFeesValue = new System.Windows.Forms.Label();
            this.lblTotalCostValue = new System.Windows.Forms.Label();
            this.lblNumOfParticipantValue = new System.Windows.Forms.Label();
            this.lblSurplusDeficit = new System.Windows.Forms.Label();
            this.lblTotalFees = new System.Windows.Forms.Label();
            this.lblTotalCost = new System.Windows.Forms.Label();
            this.lblNumOfParticipants = new System.Windows.Forms.Label();
            this.lbxParticipants = new System.Windows.Forms.ListBox();
            this.lblName = new System.Windows.Forms.Label();
            this.lblAdress = new System.Windows.Forms.Label();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.gbxEvent.SuspendLayout();
            this.gbxParticipant.SuspendLayout();
            this.gbxEventEconomy.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxEvent
            // 
            this.gbxEvent.Controls.Add(this.btnCreate);
            this.gbxEvent.Controls.Add(this.txtFee);
            this.gbxEvent.Controls.Add(this.txtCost);
            this.gbxEvent.Controls.Add(this.txtEventName);
            this.gbxEvent.Controls.Add(this.lblFee);
            this.gbxEvent.Controls.Add(this.lblCost);
            this.gbxEvent.Controls.Add(this.lblEventName);
            this.gbxEvent.Location = new System.Drawing.Point(34, 35);
            this.gbxEvent.Name = "gbxEvent";
            this.gbxEvent.Size = new System.Drawing.Size(255, 158);
            this.gbxEvent.TabIndex = 0;
            this.gbxEvent.TabStop = false;
            this.gbxEvent.Text = "New Event";
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(68, 125);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(111, 23);
            this.btnCreate.TabIndex = 6;
            this.btnCreate.Text = "Create Event";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // txtFee
            // 
            this.txtFee.Location = new System.Drawing.Point(141, 85);
            this.txtFee.Name = "txtFee";
            this.txtFee.Size = new System.Drawing.Size(48, 20);
            this.txtFee.TabIndex = 5;
            this.txtFee.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCost
            // 
            this.txtCost.Location = new System.Drawing.Point(141, 53);
            this.txtCost.Name = "txtCost";
            this.txtCost.Size = new System.Drawing.Size(48, 20);
            this.txtCost.TabIndex = 4;
            this.txtCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtEventName
            // 
            this.txtEventName.Location = new System.Drawing.Point(89, 20);
            this.txtEventName.Name = "txtEventName";
            this.txtEventName.Size = new System.Drawing.Size(100, 20);
            this.txtEventName.TabIndex = 3;
            // 
            // lblFee
            // 
            this.lblFee.AutoSize = true;
            this.lblFee.Location = new System.Drawing.Point(6, 85);
            this.lblFee.Name = "lblFee";
            this.lblFee.Size = new System.Drawing.Size(78, 13);
            this.lblFee.TabIndex = 2;
            this.lblFee.Text = "Fee per person";
            // 
            // lblCost
            // 
            this.lblCost.AutoSize = true;
            this.lblCost.Location = new System.Drawing.Point(6, 53);
            this.lblCost.Name = "lblCost";
            this.lblCost.Size = new System.Drawing.Size(98, 13);
            this.lblCost.TabIndex = 1;
            this.lblCost.Text = "Cost per participant";
            // 
            // lblEventName
            // 
            this.lblEventName.AutoSize = true;
            this.lblEventName.Location = new System.Drawing.Point(7, 20);
            this.lblEventName.Name = "lblEventName";
            this.lblEventName.Size = new System.Drawing.Size(64, 13);
            this.lblEventName.TabIndex = 0;
            this.lblEventName.Text = "Event name";
            // 
            // gbxParticipant
            // 
            this.gbxParticipant.Controls.Add(this.btnAdd);
            this.gbxParticipant.Controls.Add(this.txtFirstName);
            this.gbxParticipant.Controls.Add(this.txtLastName);
            this.gbxParticipant.Controls.Add(this.txtStreet);
            this.gbxParticipant.Controls.Add(this.txtCity);
            this.gbxParticipant.Controls.Add(this.txtZip);
            this.gbxParticipant.Controls.Add(this.cbxCountry);
            this.gbxParticipant.Controls.Add(this.lblCountry);
            this.gbxParticipant.Controls.Add(this.lblZip);
            this.gbxParticipant.Controls.Add(this.lblCity);
            this.gbxParticipant.Controls.Add(this.lblStreet);
            this.gbxParticipant.Controls.Add(this.lblLastName);
            this.gbxParticipant.Controls.Add(this.lblFirstName);
            this.gbxParticipant.Location = new System.Drawing.Point(34, 216);
            this.gbxParticipant.Name = "gbxParticipant";
            this.gbxParticipant.Size = new System.Drawing.Size(255, 222);
            this.gbxParticipant.TabIndex = 1;
            this.gbxParticipant.TabStop = false;
            this.gbxParticipant.Text = "Add participant";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(68, 193);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(95, 23);
            this.btnAdd.TabIndex = 12;
            this.btnAdd.Text = "Add participant";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(68, 20);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(121, 20);
            this.txtFirstName.TabIndex = 11;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(68, 49);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(121, 20);
            this.txtLastName.TabIndex = 10;
            // 
            // txtStreet
            // 
            this.txtStreet.Location = new System.Drawing.Point(68, 77);
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.Size = new System.Drawing.Size(121, 20);
            this.txtStreet.TabIndex = 9;
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(68, 107);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(121, 20);
            this.txtCity.TabIndex = 8;
            // 
            // txtZip
            // 
            this.txtZip.Location = new System.Drawing.Point(68, 135);
            this.txtZip.Name = "txtZip";
            this.txtZip.Size = new System.Drawing.Size(121, 20);
            this.txtZip.TabIndex = 7;
            // 
            // cbxCountry
            // 
            this.cbxCountry.FormattingEnabled = true;
            this.cbxCountry.Location = new System.Drawing.Point(68, 164);
            this.cbxCountry.Name = "cbxCountry";
            this.cbxCountry.Size = new System.Drawing.Size(121, 21);
            this.cbxCountry.TabIndex = 6;
            // 
            // lblCountry
            // 
            this.lblCountry.AutoSize = true;
            this.lblCountry.Location = new System.Drawing.Point(7, 164);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.Size = new System.Drawing.Size(43, 13);
            this.lblCountry.TabIndex = 5;
            this.lblCountry.Text = "Country";
            // 
            // lblZip
            // 
            this.lblZip.AutoSize = true;
            this.lblZip.Location = new System.Drawing.Point(7, 135);
            this.lblZip.Name = "lblZip";
            this.lblZip.Size = new System.Drawing.Size(50, 13);
            this.lblZip.TabIndex = 4;
            this.lblZip.Text = "Zip Code";
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Location = new System.Drawing.Point(7, 107);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(24, 13);
            this.lblCity.TabIndex = 3;
            this.lblCity.Text = "City";
            // 
            // lblStreet
            // 
            this.lblStreet.AutoSize = true;
            this.lblStreet.Location = new System.Drawing.Point(7, 77);
            this.lblStreet.Name = "lblStreet";
            this.lblStreet.Size = new System.Drawing.Size(35, 13);
            this.lblStreet.TabIndex = 2;
            this.lblStreet.Text = "Street";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(7, 49);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(58, 13);
            this.lblLastName.TabIndex = 1;
            this.lblLastName.Text = "Last Name";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(7, 20);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(57, 13);
            this.lblFirstName.TabIndex = 0;
            this.lblFirstName.Text = "First Name";
            // 
            // gbxEventEconomy
            // 
            this.gbxEventEconomy.Controls.Add(this.lblSurplusDeficitValue);
            this.gbxEventEconomy.Controls.Add(this.lblTotalFeesValue);
            this.gbxEventEconomy.Controls.Add(this.lblTotalCostValue);
            this.gbxEventEconomy.Controls.Add(this.lblNumOfParticipantValue);
            this.gbxEventEconomy.Controls.Add(this.lblSurplusDeficit);
            this.gbxEventEconomy.Controls.Add(this.lblTotalFees);
            this.gbxEventEconomy.Controls.Add(this.lblTotalCost);
            this.gbxEventEconomy.Controls.Add(this.lblNumOfParticipants);
            this.gbxEventEconomy.Location = new System.Drawing.Point(411, 277);
            this.gbxEventEconomy.Name = "gbxEventEconomy";
            this.gbxEventEconomy.Size = new System.Drawing.Size(228, 155);
            this.gbxEventEconomy.TabIndex = 2;
            this.gbxEventEconomy.TabStop = false;
            this.gbxEventEconomy.Text = "Event Economy";
            // 
            // lblSurplusDeficitValue
            // 
            this.lblSurplusDeficitValue.AutoSize = true;
            this.lblSurplusDeficitValue.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSurplusDeficitValue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSurplusDeficitValue.Location = new System.Drawing.Point(181, 119);
            this.lblSurplusDeficitValue.MinimumSize = new System.Drawing.Size(40, 13);
            this.lblSurplusDeficitValue.Name = "lblSurplusDeficitValue";
            this.lblSurplusDeficitValue.Size = new System.Drawing.Size(40, 15);
            this.lblSurplusDeficitValue.TabIndex = 7;
            this.lblSurplusDeficitValue.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblTotalFeesValue
            // 
            this.lblTotalFeesValue.AutoSize = true;
            this.lblTotalFeesValue.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTotalFeesValue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalFeesValue.Location = new System.Drawing.Point(181, 92);
            this.lblTotalFeesValue.MinimumSize = new System.Drawing.Size(40, 13);
            this.lblTotalFeesValue.Name = "lblTotalFeesValue";
            this.lblTotalFeesValue.Size = new System.Drawing.Size(40, 15);
            this.lblTotalFeesValue.TabIndex = 6;
            this.lblTotalFeesValue.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblTotalCostValue
            // 
            this.lblTotalCostValue.AutoSize = true;
            this.lblTotalCostValue.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTotalCostValue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalCostValue.Location = new System.Drawing.Point(181, 62);
            this.lblTotalCostValue.MinimumSize = new System.Drawing.Size(40, 13);
            this.lblTotalCostValue.Name = "lblTotalCostValue";
            this.lblTotalCostValue.Size = new System.Drawing.Size(40, 15);
            this.lblTotalCostValue.TabIndex = 5;
            this.lblTotalCostValue.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblNumOfParticipantValue
            // 
            this.lblNumOfParticipantValue.AutoSize = true;
            this.lblNumOfParticipantValue.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblNumOfParticipantValue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblNumOfParticipantValue.Location = new System.Drawing.Point(181, 33);
            this.lblNumOfParticipantValue.MinimumSize = new System.Drawing.Size(40, 13);
            this.lblNumOfParticipantValue.Name = "lblNumOfParticipantValue";
            this.lblNumOfParticipantValue.Size = new System.Drawing.Size(40, 15);
            this.lblNumOfParticipantValue.TabIndex = 4;
            this.lblNumOfParticipantValue.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblSurplusDeficit
            // 
            this.lblSurplusDeficit.AutoSize = true;
            this.lblSurplusDeficit.Location = new System.Drawing.Point(7, 119);
            this.lblSurplusDeficit.Name = "lblSurplusDeficit";
            this.lblSurplusDeficit.Size = new System.Drawing.Size(75, 13);
            this.lblSurplusDeficit.TabIndex = 3;
            this.lblSurplusDeficit.Text = "Surplus/deficit";
            // 
            // lblTotalFees
            // 
            this.lblTotalFees.AutoSize = true;
            this.lblTotalFees.Location = new System.Drawing.Point(6, 92);
            this.lblTotalFees.Name = "lblTotalFees";
            this.lblTotalFees.Size = new System.Drawing.Size(54, 13);
            this.lblTotalFees.TabIndex = 2;
            this.lblTotalFees.Text = "Total fees";
            // 
            // lblTotalCost
            // 
            this.lblTotalCost.AutoSize = true;
            this.lblTotalCost.Location = new System.Drawing.Point(6, 62);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new System.Drawing.Size(54, 13);
            this.lblTotalCost.TabIndex = 1;
            this.lblTotalCost.Text = "Total cost";
            // 
            // lblNumOfParticipants
            // 
            this.lblNumOfParticipants.AutoSize = true;
            this.lblNumOfParticipants.Location = new System.Drawing.Point(7, 33);
            this.lblNumOfParticipants.Name = "lblNumOfParticipants";
            this.lblNumOfParticipants.Size = new System.Drawing.Size(113, 13);
            this.lblNumOfParticipants.TabIndex = 0;
            this.lblNumOfParticipants.Text = "Number of participants";
            // 
            // lbxParticipants
            // 
            this.lbxParticipants.FormattingEnabled = true;
            this.lbxParticipants.Location = new System.Drawing.Point(340, 46);
            this.lbxParticipants.Name = "lbxParticipants";
            this.lbxParticipants.Size = new System.Drawing.Size(428, 147);
            this.lbxParticipants.TabIndex = 3;
            this.lbxParticipants.SelectedIndexChanged += new System.EventHandler(this.lbxParticipants_SelectedIndexChanged);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(337, 27);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(57, 13);
            this.lblName.TabIndex = 4;
            this.lblName.Text = "Participant";
            // 
            // lblAdress
            // 
            this.lblAdress.AutoSize = true;
            this.lblAdress.Location = new System.Drawing.Point(477, 27);
            this.lblAdress.Name = "lblAdress";
            this.lblAdress.Size = new System.Drawing.Size(39, 13);
            this.lblAdress.TabIndex = 5;
            this.lblAdress.Text = "Adress";
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(411, 200);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(75, 23);
            this.btnEdit.TabIndex = 8;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(579, 200);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 9;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.lblAdress);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lbxParticipants);
            this.Controls.Add(this.gbxEventEconomy);
            this.Controls.Add(this.gbxParticipant);
            this.Controls.Add(this.gbxEvent);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.gbxEvent.ResumeLayout(false);
            this.gbxEvent.PerformLayout();
            this.gbxParticipant.ResumeLayout(false);
            this.gbxParticipant.PerformLayout();
            this.gbxEventEconomy.ResumeLayout(false);
            this.gbxEventEconomy.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxEvent;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.TextBox txtFee;
        private System.Windows.Forms.TextBox txtCost;
        private System.Windows.Forms.TextBox txtEventName;
        private System.Windows.Forms.Label lblFee;
        private System.Windows.Forms.Label lblCost;
        private System.Windows.Forms.Label lblEventName;
        private System.Windows.Forms.GroupBox gbxParticipant;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtStreet;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtZip;
        private System.Windows.Forms.ComboBox cbxCountry;
        private System.Windows.Forms.Label lblCountry;
        private System.Windows.Forms.Label lblZip;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.Label lblStreet;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.GroupBox gbxEventEconomy;
        private System.Windows.Forms.ListBox lbxParticipants;
        private System.Windows.Forms.Label lblSurplusDeficitValue;
        private System.Windows.Forms.Label lblTotalFeesValue;
        private System.Windows.Forms.Label lblTotalCostValue;
        private System.Windows.Forms.Label lblNumOfParticipantValue;
        private System.Windows.Forms.Label lblSurplusDeficit;
        private System.Windows.Forms.Label lblTotalFees;
        private System.Windows.Forms.Label lblTotalCost;
        private System.Windows.Forms.Label lblNumOfParticipants;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblAdress;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnDelete;
    }
}

