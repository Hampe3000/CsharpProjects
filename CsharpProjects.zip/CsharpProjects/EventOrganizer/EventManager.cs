﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventOrganizer
{
    class EventManager
    {
        private double costPerPerson;
        private double feePerPerson;
        private ParticipantManager participantManager;
        private string title;//not used in this project

        public EventManager() 
        {
            participantManager = new ParticipantManager();
        }

        public double CalcTotalCost() //calculates the total cost of the event
        {
            return costPerPerson * participantManager.GetCount();
        }

        public double CalcTotalFees() //calculates the total fees for the event
        {
            return feePerPerson * participantManager.GetCount();
        }

        //getters & setters
        public double GetCostPerPerson() 
        {
            return costPerPerson;
        }
        public void SetCostPerPerson(double value) 
        {
            costPerPerson = value;
        }
        public double GetFeePerPerson() 
        {
            return feePerPerson;
        }
        public void SetFeePerPerson(double value) 
        {
            feePerPerson = value;
        }
        public ParticipantManager GetParticipants() 
        {
            return participantManager;
        }
        public string GetTitle() 
        {
            return title;
        }
        public void SetTitle(string value) 
        {
            title = value;
        }
    }
}
