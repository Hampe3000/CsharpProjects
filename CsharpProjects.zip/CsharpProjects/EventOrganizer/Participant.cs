﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventOrganizer
{
    class Participant
    {
        private string firstName; //the different variables this class handles
        private string lastName;
        private Address address;//from the adress class

        public Participant() : this ("Sven", "Svensson", new Address())//the constructor that provides defult values for all variables
        {

        }

        public Participant(Participant theOther) : this(theOther.GetFirstName(), theOther.GetLastName(), theOther.GetAddress())//the copy constructor
        {
            
        }

        public Participant(string firstName, string lastName, Address address) //the construcor that takes the most arguments
        {
            this.lastName = lastName;
            this.firstName = firstName;
            this.address = address;
        }

        public override string ToString() //combines all information to one string
        { 
            return string.Format("{0} {1,25}", GetFullName(), address.ToString());
        }

        private bool Validate() 
        {
            bool ok = false;
            if (!string.IsNullOrEmpty(firstName) && !string.IsNullOrEmpty(lastName)) 
            {
                ok = true;
            }
            return ok;
        }

        //setters & getters
        public Address GetAddress() 
        {
            return address;
        }
        public void SetAddress(Address value) 
        {
            address = value;
        }
        public string GetFirstName() 
        {
            return firstName;
        }
        public void SetFirstName(string value) 
        {
            firstName = value;
        }
        public string GetLastName() 
        {
            return lastName;
        }
        public void SetLastName(string value) 
        {
            lastName = value;
        }
        public string GetFullName() 
        {
            string fullName = lastName + ' ' + firstName;
            return fullName;
        }
    }
}
