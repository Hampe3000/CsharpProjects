﻿
namespace Party_Organizer
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbxNewParty = new System.Windows.Forms.GroupBox();
            this.lblMaxGuests = new System.Windows.Forms.Label();
            this.lblCostPerPerson = new System.Windows.Forms.Label();
            this.lblFeePerPerson = new System.Windows.Forms.Label();
            this.btnCreateList = new System.Windows.Forms.Button();
            this.txtMaxNumGuests = new System.Windows.Forms.TextBox();
            this.txtCostPerPerson = new System.Windows.Forms.TextBox();
            this.txtFeePerPerson = new System.Windows.Forms.TextBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.gbxInviteGuest = new System.Windows.Forms.GroupBox();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblLastName = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lblNumOfGuests = new System.Windows.Forms.Label();
            this.lblTotalCost = new System.Windows.Forms.Label();
            this.lblTotalFees = new System.Windows.Forms.Label();
            this.lblSurplusDeficit = new System.Windows.Forms.Label();
            this.lblNumOfGuestsValue = new System.Windows.Forms.Label();
            this.lblTotalCostValue = new System.Windows.Forms.Label();
            this.lblTotalFeesValue = new System.Windows.Forms.Label();
            this.lblSurplusDeficitValue = new System.Windows.Forms.Label();
            this.lblGuestList = new System.Windows.Forms.Label();
            this.lbxGuestlist = new System.Windows.Forms.ListBox();
            this.btnChange = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.gbxNewParty.SuspendLayout();
            this.gbxInviteGuest.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxNewParty
            // 
            this.gbxNewParty.Controls.Add(this.lblMaxGuests);
            this.gbxNewParty.Controls.Add(this.lblCostPerPerson);
            this.gbxNewParty.Controls.Add(this.lblFeePerPerson);
            this.gbxNewParty.Controls.Add(this.btnCreateList);
            this.gbxNewParty.Controls.Add(this.txtMaxNumGuests);
            this.gbxNewParty.Controls.Add(this.txtCostPerPerson);
            this.gbxNewParty.Controls.Add(this.txtFeePerPerson);
            this.gbxNewParty.Location = new System.Drawing.Point(12, 8);
            this.gbxNewParty.Name = "gbxNewParty";
            this.gbxNewParty.Size = new System.Drawing.Size(202, 137);
            this.gbxNewParty.TabIndex = 0;
            this.gbxNewParty.TabStop = false;
            this.gbxNewParty.Text = "New Party";
            // 
            // lblMaxGuests
            // 
            this.lblMaxGuests.AutoSize = true;
            this.lblMaxGuests.Location = new System.Drawing.Point(6, 22);
            this.lblMaxGuests.Name = "lblMaxGuests";
            this.lblMaxGuests.Size = new System.Drawing.Size(111, 13);
            this.lblMaxGuests.TabIndex = 2;
            this.lblMaxGuests.Text = "Max number of guests";
            // 
            // lblCostPerPerson
            // 
            this.lblCostPerPerson.AutoSize = true;
            this.lblCostPerPerson.Location = new System.Drawing.Point(6, 45);
            this.lblCostPerPerson.Name = "lblCostPerPerson";
            this.lblCostPerPerson.Size = new System.Drawing.Size(81, 13);
            this.lblCostPerPerson.TabIndex = 3;
            this.lblCostPerPerson.Text = "Cost per person";
            // 
            // lblFeePerPerson
            // 
            this.lblFeePerPerson.AutoSize = true;
            this.lblFeePerPerson.Location = new System.Drawing.Point(6, 71);
            this.lblFeePerPerson.Name = "lblFeePerPerson";
            this.lblFeePerPerson.Size = new System.Drawing.Size(78, 13);
            this.lblFeePerPerson.TabIndex = 4;
            this.lblFeePerPerson.Text = "Fee per person";
            // 
            // btnCreateList
            // 
            this.btnCreateList.Location = new System.Drawing.Point(65, 97);
            this.btnCreateList.Name = "btnCreateList";
            this.btnCreateList.Size = new System.Drawing.Size(75, 23);
            this.btnCreateList.TabIndex = 22;
            this.btnCreateList.Text = "Create list";
            this.btnCreateList.UseVisualStyleBackColor = true;
            this.btnCreateList.Click += new System.EventHandler(this.btnCreateList_click);
            // 
            // txtMaxNumGuests
            // 
            this.txtMaxNumGuests.Location = new System.Drawing.Point(124, 19);
            this.txtMaxNumGuests.Name = "txtMaxNumGuests";
            this.txtMaxNumGuests.Size = new System.Drawing.Size(53, 20);
            this.txtMaxNumGuests.TabIndex = 16;
            // 
            // txtCostPerPerson
            // 
            this.txtCostPerPerson.Location = new System.Drawing.Point(124, 45);
            this.txtCostPerPerson.Name = "txtCostPerPerson";
            this.txtCostPerPerson.Size = new System.Drawing.Size(53, 20);
            this.txtCostPerPerson.TabIndex = 17;
            // 
            // txtFeePerPerson
            // 
            this.txtFeePerPerson.Location = new System.Drawing.Point(124, 71);
            this.txtFeePerPerson.Name = "txtFeePerPerson";
            this.txtFeePerPerson.Size = new System.Drawing.Size(53, 20);
            this.txtFeePerPerson.TabIndex = 18;
            // 
            // gbxInviteGuest
            // 
            this.gbxInviteGuest.Controls.Add(this.lblFirstName);
            this.gbxInviteGuest.Controls.Add(this.txtFirstName);
            this.gbxInviteGuest.Controls.Add(this.btnAdd);
            this.gbxInviteGuest.Controls.Add(this.lblLastName);
            this.gbxInviteGuest.Controls.Add(this.txtLastName);
            this.gbxInviteGuest.Location = new System.Drawing.Point(12, 155);
            this.gbxInviteGuest.Name = "gbxInviteGuest";
            this.gbxInviteGuest.Size = new System.Drawing.Size(202, 145);
            this.gbxInviteGuest.TabIndex = 1;
            this.gbxInviteGuest.TabStop = false;
            this.gbxInviteGuest.Text = "Invite Guest";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(6, 45);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(55, 13);
            this.lblFirstName.TabIndex = 5;
            this.lblFirstName.Text = "First name";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(65, 45);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(112, 20);
            this.txtFirstName.TabIndex = 19;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(65, 116);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 24;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(6, 79);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(56, 13);
            this.lblLastName.TabIndex = 6;
            this.lblLastName.Text = "Last name";
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(65, 79);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(112, 20);
            this.txtLastName.TabIndex = 20;
            // 
            // lblNumOfGuests
            // 
            this.lblNumOfGuests.AutoSize = true;
            this.lblNumOfGuests.Location = new System.Drawing.Point(18, 322);
            this.lblNumOfGuests.Name = "lblNumOfGuests";
            this.lblNumOfGuests.Size = new System.Drawing.Size(92, 13);
            this.lblNumOfGuests.TabIndex = 7;
            this.lblNumOfGuests.Text = "Number of Guests";
            // 
            // lblTotalCost
            // 
            this.lblTotalCost.AutoSize = true;
            this.lblTotalCost.Location = new System.Drawing.Point(18, 346);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new System.Drawing.Size(54, 13);
            this.lblTotalCost.TabIndex = 8;
            this.lblTotalCost.Text = "Total cost";
            // 
            // lblTotalFees
            // 
            this.lblTotalFees.AutoSize = true;
            this.lblTotalFees.Location = new System.Drawing.Point(18, 372);
            this.lblTotalFees.Name = "lblTotalFees";
            this.lblTotalFees.Size = new System.Drawing.Size(54, 13);
            this.lblTotalFees.TabIndex = 9;
            this.lblTotalFees.Text = "Total fees";
            // 
            // lblSurplusDeficit
            // 
            this.lblSurplusDeficit.AutoSize = true;
            this.lblSurplusDeficit.Location = new System.Drawing.Point(18, 402);
            this.lblSurplusDeficit.Name = "lblSurplusDeficit";
            this.lblSurplusDeficit.Size = new System.Drawing.Size(75, 13);
            this.lblSurplusDeficit.TabIndex = 10;
            this.lblSurplusDeficit.Text = "Surplus/deficit";
            // 
            // lblNumOfGuestsValue
            // 
            this.lblNumOfGuestsValue.AutoSize = true;
            this.lblNumOfGuestsValue.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblNumOfGuestsValue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblNumOfGuestsValue.Location = new System.Drawing.Point(136, 320);
            this.lblNumOfGuestsValue.MinimumSize = new System.Drawing.Size(40, 0);
            this.lblNumOfGuestsValue.Name = "lblNumOfGuestsValue";
            this.lblNumOfGuestsValue.Size = new System.Drawing.Size(40, 15);
            this.lblNumOfGuestsValue.TabIndex = 11;
            this.lblNumOfGuestsValue.Text = "0";
            this.lblNumOfGuestsValue.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblTotalCostValue
            // 
            this.lblTotalCostValue.AutoSize = true;
            this.lblTotalCostValue.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTotalCostValue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalCostValue.Location = new System.Drawing.Point(136, 344);
            this.lblTotalCostValue.MinimumSize = new System.Drawing.Size(40, 0);
            this.lblTotalCostValue.Name = "lblTotalCostValue";
            this.lblTotalCostValue.Size = new System.Drawing.Size(40, 15);
            this.lblTotalCostValue.TabIndex = 12;
            this.lblTotalCostValue.Text = "0";
            this.lblTotalCostValue.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblTotalFeesValue
            // 
            this.lblTotalFeesValue.AutoSize = true;
            this.lblTotalFeesValue.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTotalFeesValue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalFeesValue.Location = new System.Drawing.Point(136, 370);
            this.lblTotalFeesValue.MinimumSize = new System.Drawing.Size(40, 0);
            this.lblTotalFeesValue.Name = "lblTotalFeesValue";
            this.lblTotalFeesValue.Size = new System.Drawing.Size(40, 15);
            this.lblTotalFeesValue.TabIndex = 13;
            this.lblTotalFeesValue.Text = "0";
            this.lblTotalFeesValue.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblSurplusDeficitValue
            // 
            this.lblSurplusDeficitValue.AutoSize = true;
            this.lblSurplusDeficitValue.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSurplusDeficitValue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSurplusDeficitValue.Location = new System.Drawing.Point(136, 400);
            this.lblSurplusDeficitValue.MinimumSize = new System.Drawing.Size(40, 0);
            this.lblSurplusDeficitValue.Name = "lblSurplusDeficitValue";
            this.lblSurplusDeficitValue.Size = new System.Drawing.Size(40, 15);
            this.lblSurplusDeficitValue.TabIndex = 14;
            this.lblSurplusDeficitValue.Text = "0";
            this.lblSurplusDeficitValue.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblGuestList
            // 
            this.lblGuestList.AutoSize = true;
            this.lblGuestList.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGuestList.Location = new System.Drawing.Point(247, 9);
            this.lblGuestList.Name = "lblGuestList";
            this.lblGuestList.Size = new System.Drawing.Size(80, 21);
            this.lblGuestList.TabIndex = 15;
            this.lblGuestList.Text = "Guest list";
            // 
            // lbxGuestlist
            // 
            this.lbxGuestlist.FormattingEnabled = true;
            this.lbxGuestlist.Location = new System.Drawing.Point(251, 43);
            this.lbxGuestlist.Name = "lbxGuestlist";
            this.lbxGuestlist.Size = new System.Drawing.Size(166, 329);
            this.lbxGuestlist.TabIndex = 21;
            this.lbxGuestlist.SelectedIndexChanged += new System.EventHandler(this.lbxGuestlist_SelectedIndexChanged);
            // 
            // btnChange
            // 
            this.btnChange.Location = new System.Drawing.Point(251, 392);
            this.btnChange.Name = "btnChange";
            this.btnChange.Size = new System.Drawing.Size(75, 23);
            this.btnChange.TabIndex = 25;
            this.btnChange.Text = "Change";
            this.btnChange.UseVisualStyleBackColor = true;
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(342, 392);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 26;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(439, 450);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnChange);
            this.Controls.Add(this.lbxGuestlist);
            this.Controls.Add(this.lblGuestList);
            this.Controls.Add(this.lblSurplusDeficitValue);
            this.Controls.Add(this.lblTotalFeesValue);
            this.Controls.Add(this.lblTotalCostValue);
            this.Controls.Add(this.lblNumOfGuestsValue);
            this.Controls.Add(this.lblSurplusDeficit);
            this.Controls.Add(this.lblTotalFees);
            this.Controls.Add(this.lblTotalCost);
            this.Controls.Add(this.lblNumOfGuests);
            this.Controls.Add(this.gbxInviteGuest);
            this.Controls.Add(this.gbxNewParty);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.gbxNewParty.ResumeLayout(false);
            this.gbxNewParty.PerformLayout();
            this.gbxInviteGuest.ResumeLayout(false);
            this.gbxInviteGuest.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxNewParty;
        private System.Windows.Forms.Label lblMaxGuests;
        private System.Windows.Forms.Label lblCostPerPerson;
        private System.Windows.Forms.Label lblFeePerPerson;
        private System.Windows.Forms.Button btnCreateList;
        private System.Windows.Forms.TextBox txtMaxNumGuests;
        private System.Windows.Forms.TextBox txtCostPerPerson;
        private System.Windows.Forms.TextBox txtFeePerPerson;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox gbxInviteGuest;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lblNumOfGuests;
        private System.Windows.Forms.Label lblTotalCost;
        private System.Windows.Forms.Label lblTotalFees;
        private System.Windows.Forms.Label lblSurplusDeficit;
        private System.Windows.Forms.Label lblNumOfGuestsValue;
        private System.Windows.Forms.Label lblTotalCostValue;
        private System.Windows.Forms.Label lblTotalFeesValue;
        private System.Windows.Forms.Label lblSurplusDeficitValue;
        private System.Windows.Forms.Label lblGuestList;
        private System.Windows.Forms.ListBox lbxGuestlist;
        private System.Windows.Forms.Button btnChange;
        private System.Windows.Forms.Button btnDelete;
    }
}

