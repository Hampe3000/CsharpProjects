﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Party_Organizer
{
    public partial class MainForm : Form
    {
        PartyManager partyManager;//declared but not created
        public MainForm()
        {
            InitializeComponent();
            InitializeGUI();
        }
        private void InitializeGUI()// edits the name of the form and disables the ad guest groupbox
        {
            Text = "Party Manager by Hampu Oxenholt";
            gbxInviteGuest.Enabled = false;
            DisableBUTT();
        }
        private void UpdateGUI() //Update the guis labels and list box and clears the name textboxes
        {
            lbxGuestlist.Items.Clear();//update the listbox
            string[] Guestlist = partyManager.GetGuestList();
            if (Guestlist != null)
            {
                for (int i = 0; i < Guestlist.Length; i++)
                {
                    string str = $"{i + 1 , 4} {Guestlist[i],-20}";
                    lbxGuestlist.Items.Add(str);
                }
            }
            else 
            {
                return;
            }

            double totalCost = partyManager.CalcTotalcost();//update the total cost 
            lblTotalCostValue.Text = totalCost.ToString("0.00");

            double totalFees = partyManager.CalcTotalFees();//updates the total fees 
            lblTotalFeesValue.Text = totalFees.ToString("0.00");

            double surplus_deficit = partyManager.CalcSurplus_Deficit();//updates the surplus/deficit
            lblSurplusDeficitValue.Text = surplus_deficit.ToString("0.00");

            int numOfGuests = partyManager.NumOfGuests();//updates the number of guests
            lblNumOfGuestsValue.Text = numOfGuests.ToString();
        }

        private void btnCreateList_click(object sender, EventArgs e)
        {
            ClearLabels();
            int maxNumber = 0;
            int.TryParse(txtMaxNumGuests.Text, out maxNumber);

            bool maxNumOK = CreateParty();
            if (!maxNumOK) 
            {
                return;
            }
            bool amountOK = ReadCostPerPerson() && ReadFeesPerPerson();
            if (maxNumOK && amountOK) 
            {
                MessageBox.Show($"Party list with space for {maxNumber} guests has been created!", "Success");//success message
                gbxInviteGuest.Enabled = true;
                UpdateGUI();
            }
        }
        private bool CreateParty() 
        {
            int maxNumber = 0;
            bool ok = true;
            if (int.TryParse(txtMaxNumGuests.Text, out maxNumber) && (maxNumber > 0))
            {
                partyManager = new PartyManager(maxNumber);
            }
            else 
            {
                MessageBox.Show("The number of guests must be a whole number");//error message
                ok = false;
            }
            return ok;
        }
        private bool ReadCostPerPerson() 
        {
            double costPerPerson = 0.0;
            bool ok = double.TryParse(txtCostPerPerson.Text, out costPerPerson);
            if (ok)
            {
                partyManager.SetCostPerPerson(costPerPerson);
            }
            else 
            {
                MessageBox.Show("invalid input");//error message
                ok = false;
            }
            return ok;
        }
        private bool ReadFeesPerPerson()
        {
            double feesPerPerson = 0.0;
            bool ok = double.TryParse(txtFeePerPerson.Text, out feesPerPerson);
            if (ok && feesPerPerson >= 0)
            {
                partyManager.SetFeesPerPerson(feesPerPerson);
            }
            else
            {
                MessageBox.Show("invalid input");//error message
                ok = false;
            }
            return ok;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int maxNumber = 0;
            int.TryParse(txtMaxNumGuests.Text, out maxNumber);
            
            if (partyManager.NumOfGuests() != maxNumber)
            {
                if((NameOK(txtFirstName.Text) == true ) && (NameOK(txtLastName.Text) == true))
                partyManager.AddNewGuest(txtFirstName.Text, txtLastName.Text);
            }
            else 
            {
                MessageBox.Show("Sorry the list is full :(");//error message
                DisableBUTT();
            }
            UpdateGUI();
            ClearTextBoxes();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            partyManager.DeleteAt(IsListBoxItemSelected());
            DisableBUTT();
            UpdateGUI();
            ClearTextBoxes();
        }

        private bool ValidText(string firstName, string lastName) //checks so that the names aren't empty
        {
            bool ok = true;
            if ((firstName == string.Empty) || (lastName == string.Empty))
            {
                ok = false;
            }
            return ok;
        }
        private bool NameOK(string name) 
        {
            bool ok = true;
            if (string.IsNullOrEmpty(name)) 
            {
                MessageBox.Show("Thats not a valid name");//error message
                ok = false;
            }
            return ok;
        }
        private void ClearLabels() //clears the value labels
        {
            lblNumOfGuestsValue.Text = "0";
            lblSurplusDeficitValue.Text = "0";
            lblTotalCostValue.Text = "0";
            lblTotalFeesValue.Text = "0";
        }

        private void lbxGuestlist_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = IsListBoxItemSelected();
            if (index >= 0) 
            {
                string name = partyManager.GetItemAt(index);
                string[] names = name.Split(',');
                txtFirstName.Text = names[1].Trim();
                txtLastName.Text = names[0].Trim();
                btnChange.Enabled = true;
                btnDelete.Enabled = true;
            }
            
        }
        private int IsListBoxItemSelected() 
        {
            int index = lbxGuestlist.SelectedIndex;
            return index;
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            partyManager.DeleteAt(IsListBoxItemSelected());
            partyManager.AddNewGuest(txtFirstName.Text, txtLastName.Text);
            DisableBUTT();
            UpdateGUI();
            ClearTextBoxes();
        }
        private void ClearTextBoxes() //emptys the name input boxes
        {
            txtFirstName.Text = string.Empty;
            txtLastName.Text = string.Empty;
        }
        private void DisableBUTT()//disables the delete and change button 
        {
            btnChange.Enabled = false;
            btnDelete.Enabled = false;
        }
    }
}
