﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Party_Organizer
{
    class PartyManager
    {
        private double costPerPerson = 0.0;//
        private double feesPerPerson = 0.0;//
        private string[] GuestList;//fullname of the guests
        public PartyManager(int maxNumOfGuests) 
        {
            GuestList = new string[maxNumOfGuests]; 


        }
        public double CostPerPerson 
        {
            get { return costPerPerson; }
            set 
            {
                if(value >= 0.0)//can be equal to zero if it's free entry
                costPerPerson = value;
            }
        }
        public double FeesPerPerson 
        {
            get { return feesPerPerson; }
            set 
            {
                if (value >= 0.0)// can be equal to zero if there are no fees
                    feesPerPerson = value;
            }
        }

        public bool AddNewGuest(string firstName, string lastName) //adds a new guest to a free index in the list
        {
            bool ok = true;
            int vaccantPos = FindVacantPos();
            
            if (vaccantPos != -1)
            {
                GuestList[vaccantPos] = FullName(firstName, lastName);
            }
            else    //if there are no empty slots left in the array
            { 
                ok = false; 
            }
            return ok;
        }
     
        public double CalcTotalcost() //calculates the total cost for the party
        {
            double totalCost = NumOfGuests() * costPerPerson;
            return totalCost;
        }
        public double CalcTotalFees() //calculates the total fees for the party
        {
            double totalFees = NumOfGuests() * feesPerPerson;
            return totalFees;
        }
        public double CalcSurplus_Deficit() //calculates the surplus or deficit for the party 
        {
            double surplus_deficit = CalcTotalFees() - CalcTotalcost();
            return surplus_deficit;
        }
        public bool DeleteAt(int index) 
        {

            bool ok = false;
            int i = NumOfGuests();
                GuestList[index] = string.Empty;
            if (i != 1) { MoveElemntsOneStepToTheLeft(index); }
                if(GuestList[index]!=string.Empty)
                ok = true;
            
            return ok;
        }

        private int FindVacantPos() //the caller of this method must check that the return is'nt -1 
        {
            int vaccantPos = -1;
            for (int index = 0; index < GuestList.Length; index++)
            {
                if (string.IsNullOrEmpty (GuestList[index])) 
                {
                    vaccantPos = index;
                    break;
                }
            }
            return vaccantPos;
        }
        private string FullName(string firstName, string lastName) //combines the first and last name to one string
        {
            firstName = firstName.Trim();
            lastName = lastName.Trim();
            return lastName.ToUpper() +  ',' + firstName;
        }
        private void MoveElemntsOneStepToTheLeft(int index) //used when an item is deleted
        {
            for (int i = index + 1; i < GuestList.Length; i++) 
            {
                GuestList[i - 1] = GuestList[i]; //moves the item one step to the left
                GuestList[i] = string.Empty; //emptys the items previous position
            }
        }
        public int NumOfGuests() //creates a counter for the number of filled positions in the list
        {
            int numOfGuests = 0;
            for (int i = 0; i < GuestList.Length; i++) 
            {
                if (!string.IsNullOrEmpty(GuestList[i])) 
                {
                    numOfGuests++;
                }
            }
            return numOfGuests;
        }
        public string[] GetGuestList() //used to display a list of the filled values in the array
        {
            int size = NumOfGuests();
            if (size <=0 ) 
            {
                return null;
            }

            string[] guests = new string[size]; //creates an array with the same numbers of positons as registerd guests
            for (int i = 0, j = 0; i < GuestList.Length; i++) 
            {
                if (!string.IsNullOrEmpty(GuestList[i])) //transfers only filled positions of the array
                {
                    guests[j++] = GuestList[i];
                }
            }
            return guests;
        }
        public string GetItemAt(int index) //finds the name at given index
        {
            string fullName = GuestList[index];
            return fullName;
        }

        //setters and getters
        public double GetCostPerPerson() 
        {
            return costPerPerson;
        }
        public void SetCostPerPerson(double value) 
        {
            if (value >= 0) 
            {
                costPerPerson = value;
            }
        }
        public double GetFeesPerPerson() 
        {
            return feesPerPerson;
        }
        public void SetFeesPerPerson(double value) 
        {
            if(value >= 0)
            {
                feesPerPerson = value;
            }
        }

    }
}
