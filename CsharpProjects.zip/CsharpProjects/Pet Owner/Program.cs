﻿using System;

namespace Pet_Owner
{
       public class Pet
    {
        //Variables Name, Age, Is female?

        private string name;
        private int age;
        private bool isFemale; // Yes/No

        static void Main(string[] args)
        {
            //Create object
            Pet petObj = new Pet();
            petObj.Start();
        }

        public void Start()
        {
            //Opening Line
            Console.WriteLine("Welcome to the pet form.");
            Console.WriteLine("Please fill out the information below.");
            Console.ReadLine();

            ReadAndSavePetData();
            DisplayPetInfo();
        }
        //Input
        public void ReadAndSavePetData()
        {
            //Read name
            Console.WriteLine("Whaat is the name of your pet?");
            name = Console.ReadLine();

            //Read age
            Console.WriteLine("What is " + name + "'s Age?");
            string textvalue = Console.ReadLine();
            age = int.Parse(textvalue);

            //Read isFemale
            Console.WriteLine("Is your pet a female?");
            string strGender = Console.ReadLine();
            strGender = strGender.Trim();
            char response = strGender[0];

            if ((response == 'Y') || (response == 'y'))
            {
                isFemale = true;
            }
            else
            {
                isFemale = false;
            }
        }

        //Output
        public void DisplayPetInfo()
        {
            Console.WriteLine("***************************************************************************************");
            Console.WriteLine(name + " is ");   //Display name
            Console.WriteLine(age + " years old");   //Display age

            if (isFemale == true)
            {
                Console.WriteLine("and a good girl.");  //Display if female
            }

            else
            {
                Console.WriteLine("and a good boy.");  //Display if male
            }

            Console.WriteLine("***************************************************************************************");
            Console.WriteLine("Press enter to fill out the form again."); 
            Console.ReadLine();
            Start();//Loop program
        }
    } 
}
