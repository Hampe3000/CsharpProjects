﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BMICalculator_by_Hampus_Oxenholt
{
    class BMICalculator
    {
        private double height = 0;
        private double weight = 0;
        private UnitTypes unitTypes; //= new UnitTypes();

        public double BMICalc()
        {
            double result = 0.0;
            if (unitTypes == UnitTypes.Metric)
            {
                result = weight / (height * height);
            }

            if (unitTypes == UnitTypes.Imperial)
            {
                result = 703.0 * weight / (height * height);
            }

            return result;
        }

        public string WeightClass() //determine weightclass
        {
            double result = BMICalc();
            string weightclass = string.Empty;
            if (result < 18.5)
            {
                weightclass = "Underweight";
            }

            if (result >= 18.5 && result < 25.0)
            {
                weightclass = "Normalweight";
            }

            if (result >= 25.0 && result < 30.0)
            {
                weightclass = "Overweight (Pre-obesity)";
            }

            if (result >= 30.0 && result < 35.0)
            {
                weightclass = "Overweight (Obesity class I)";
            }

            if (result >= 35.0 && result < 40.0)
            {
                weightclass = "Overweight (Obesity class II)";
            }

            if (result >= 40.0)
            {
                weightclass = "Overweight (Obesity class III)";
            }

            return weightclass;
        }

        public string BMIInfo() //determines relevant info about your BMI
        {
            string bmiInfo = string.Empty;
            double result = BMICalc();
            if (result < 18.5)
            {
                bmiInfo = "Underweight BMI is below 18.5";
            }

            if (result >= 18.5 && result < 25.0)
            {
                bmiInfo = "Normalweight BMI is between 18.5 and 24.9";
            }

            if (result >= 25.0 && result < 30.0)
            {
                bmiInfo = "Pre-obesity BMI is between 25.0 and 29.9";
            }

            if (result >= 30.0 && result < 35.0)
            {
                bmiInfo = "Obesity class I BMI is between 30.0 and 34.9";
            }

            if (result >= 35.0 && result < 40.0)
            {
                bmiInfo = "Obesity class II BMI is between 35.0 and 39.9";
            }

            if (result >= 40.0)
            {
                bmiInfo = "Obesity class III BMI is above 40";
            }

            return bmiInfo;
        }

        public string WeightInfo() //determines relevant info regarding were you place in your weightclass
        {
            string WeightInfo = string.Empty;
            double result = BMICalc();
            if (result < 18.5)
            {
                if (unitTypes == UnitTypes.Metric)
                {
                    WeightInfo = "Underweight is below " + (18.5 * height * height) + "kg";
                }

                if (unitTypes == UnitTypes.Imperial)
                {
                    WeightInfo = "Underweight is below " + (18.5 / 703 * height * height) + "lbs";
                }
            }

            if (result >= 18.5 && result < 25.0)
            {
                if (unitTypes == UnitTypes.Metric)
                {
                    WeightInfo = "Normalweight is between " + (18.5 * height * height) + " and " +
                                 (24.9 * height * height) + "kg";
                }
                else
                {
                    WeightInfo = "Normalweight is between " + (18.5 / 703 * height * height) + " and " +
                                 (24.9 / 703 * height * height) + "lbs";
                }
            }

            if (result >= 25.0 && result < 30.0)
            {
                if (unitTypes == UnitTypes.Metric)
                {
                    WeightInfo = "Overweight (Pre-obesity) is between " + (25.0 * height * height) + " and " +
                                 (29.9 * height * height) + "kg";
                }
                else
                {
                    WeightInfo = "Overweight (Pre-obesity) is between " + (25.0 / 703 * height * height) + " and " +
                                 (29.9 / 703 * height * height) + "lbs";
                }
            }

            if (result >= 30.0 && result < 35.0)
            {
                if (unitTypes == UnitTypes.Metric)
                {
                    WeightInfo = "Overweight (Obesity class I) is between " + (30.0 * height * height) + " and " +
                                 (34.9 * height * height) + "kg";
                }
                else
                {
                    WeightInfo = "Overweight (Obesity class I) is between " + (30.0 / 703 * height * height) + " and " +
                                 (34.9 / 703 * height * height) + "lbs";
                }
            }

            if (result >= 35.0 && result < 40.0)
            {
                if (unitTypes == UnitTypes.Metric)
                {
                    WeightInfo = "Overweight (Obesity class II) is between " + (35.0 * height * height) + " and " +
                                 (39.9 * height * height) + "kg";
                }
                else
                {
                    WeightInfo = "Overweight (Obesity class II) is between " + (35.0 / 703 * height * height) + " and " +
                                 (39.9 / 703 * height * height) + "lbs";
                }
            }

            if (result >= 40.0)
            {
                if (unitTypes == UnitTypes.Metric)
                {
                    WeightInfo = "Overweight (Obesity class III) is above " + (40.0 * height * height) + "kg";
                }
                else
                {
                    WeightInfo = "Overweight (Obesity class III) is above " + (40.0/703 * height * height) + "lbs";
                }
            }

            return WeightInfo;
        }

        // Getters and Setters for the different types of inputs
        public double GetHeight()
        {
            return height;
        }

        public void SetHeight(double value)
        {
            if (value >= 0)
            {
                height = value;
            }
        }

        public double GetWeight()
        {
            return weight;
        }

        public void SetWeight(double value)
        {
            if (value > 0)
            {
                weight = value;
            }
        }

        public UnitTypes GetUnitType()
        {
            return unitTypes;
        }

        public void SetUnitType(UnitTypes value)
        {
            unitTypes = value;
        }
    }
}