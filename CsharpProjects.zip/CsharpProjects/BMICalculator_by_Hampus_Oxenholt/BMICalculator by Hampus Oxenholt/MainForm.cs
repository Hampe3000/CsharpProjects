﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMICalculator_by_Hampus_Oxenholt
{
    public partial class MainForm : Form
    {
        // private instance of class BMICalculator.
        private BMICalculator bmiCalculator = new BMICalculator();

        public MainForm()
        {
            InitializeComponent();
            InitializeGUI();
        }

        private void InitializeGUI()//fix the form so it looks nice for the user (renaming and hiding labels)
        {
            Text = "BMICalculator by Hampus Oxenholt";
            lblBMIinfo.Text = string.Empty;
            lblWeightinfo.Text = string.Empty;
        }

        private void rBtnImperial_CheckedChanged(object sender, EventArgs e)//if the imperial radiobutton is selected
        {
            if (true)
            {
                txtHeight2.Visible = true;
                lblHeight.Text = "Height (feet, in)";
                lblWeight.Text = "Weight (lbs)";
                bmiCalculator.SetUnitType(UnitTypes.Imperial);
            }
        }

        private void rBtnMetric_CheckedChanged(object sender, EventArgs e)//if the metric radiobutton is selected
        {
            if (true)
            {
                txtHeight2.Visible = false;
                lblHeight.Text = "Height (m)";
                lblWeight.Text = "Weight (kg)";
                bmiCalculator.SetUnitType(UnitTypes.Metric);
            }
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // reads input
            ReadInputWeight();
            ReadInputHeight();

            //display result from BMICalculator
            DisplayBMI();
        }

        private bool ReadInputWeight()
        {
            double weight = 0;
            bool ok = double.TryParse(txtWeight.Text, out weight);
            if (ok)
            {
                if (weight > 0) //weight has to be bigger than 0
                {
                    bmiCalculator.SetWeight(weight);
                }
            }
            else
            {
                ok = false;
                MessageBox.Show("Invalid weight");//error message
            }

            return ok;
        }

        private bool ReadInputHeight()
        {
            double height1 = 0;
            double height2 = 0;
            bool ok = double.TryParse(txtHeight1.Text, out height1);

            if (ok)
            {
                if (height1 > 0) //height must be bigger than 0
                {
                    if (bmiCalculator.GetUnitType() == UnitTypes.Imperial)
                    {
                        bool ok2 = double.TryParse(txtHeight2.Text, out height2);
                        if (ok2 == true && height2 >= 0) //height must be at least 0
                        {
                            bmiCalculator.SetHeight(height1 * 12.00 + height2);
                        }
                        else
                        {
                            ok = false;
                            MessageBox.Show("Invalid height"); //error message
                        }
                    }
                    else
                    {
                        bmiCalculator.SetHeight(height1);
                    }
                }
                else
                {
                    ok = false;
                    MessageBox.Show("Invalid height"); //error message
                }
            }
            else
            {
                MessageBox.Show("Invalid height"); //error message
            }

            return ok;
        }

        private void DisplayBMI()
        {
            if (txtYourName.Text == string.Empty) //depends on enterd Name
            {
                gBoxResult.Text = "Results for Mystery Person";
            }
            else
            {
                gBoxResult.Text = "Results for " + txtYourName.Text;
            }

            lblBMI.Text = bmiCalculator.BMICalc().ToString(); //from BMICalculator
            lblWeightclass.Text = bmiCalculator.WeightClass();
            lblBMIinfo.Text = bmiCalculator.BMIInfo();
            lblWeightinfo.Text = bmiCalculator.WeightInfo();
        }
    }
}