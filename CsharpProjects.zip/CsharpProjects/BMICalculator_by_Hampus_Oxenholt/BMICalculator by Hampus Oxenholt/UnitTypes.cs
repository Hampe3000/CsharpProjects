﻿namespace BMICalculator_by_Hampus_Oxenholt
{
    enum UnitTypes
    {
        Metric,
        Imperial
    }
}