﻿
namespace BMICalculator_by_Hampus_Oxenholt
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalculate = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblHeight = new System.Windows.Forms.Label();
            this.lblWeight = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblBMI = new System.Windows.Forms.Label();
            this.lblWeightclass = new System.Windows.Forms.Label();
            this.txtYourName = new System.Windows.Forms.TextBox();
            this.txtHeight1 = new System.Windows.Forms.TextBox();
            this.txtWeight = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rBtnImperial = new System.Windows.Forms.RadioButton();
            this.rBtnMetric = new System.Windows.Forms.RadioButton();
            this.gBoxResult = new System.Windows.Forms.GroupBox();
            this.lblWeightinfo = new System.Windows.Forms.Label();
            this.lblBMIinfo = new System.Windows.Forms.Label();
            this.txtHeight2 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.gBoxResult.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(124, 160);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(75, 23);
            this.btnCalculate.TabIndex = 0;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Your Name";
            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.Location = new System.Drawing.Point(38, 64);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(55, 13);
            this.lblHeight.TabIndex = 2;
            this.lblHeight.Text = "Height (m)";
            // 
            // lblWeight
            // 
            this.lblWeight.AutoSize = true;
            this.lblWeight.Location = new System.Drawing.Point(38, 97);
            this.lblWeight.Name = "lblWeight";
            this.lblWeight.Size = new System.Drawing.Size(62, 13);
            this.lblWeight.TabIndex = 3;
            this.lblWeight.Text = "Weight (kg)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Your BMI";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 68);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Weight Category";
            // 
            // lblBMI
            // 
            this.lblBMI.AutoSize = true;
            this.lblBMI.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblBMI.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBMI.Location = new System.Drawing.Point(126, 27);
            this.lblBMI.MinimumSize = new System.Drawing.Size(30, 2);
            this.lblBMI.Name = "lblBMI";
            this.lblBMI.Size = new System.Drawing.Size(30, 15);
            this.lblBMI.TabIndex = 6;
            this.lblBMI.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblWeightclass
            // 
            this.lblWeightclass.AutoSize = true;
            this.lblWeightclass.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblWeightclass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblWeightclass.Location = new System.Drawing.Point(126, 68);
            this.lblWeightclass.MinimumSize = new System.Drawing.Size(100, 2);
            this.lblWeightclass.Name = "lblWeightclass";
            this.lblWeightclass.Size = new System.Drawing.Size(100, 15);
            this.lblWeightclass.TabIndex = 7;
            // 
            // txtYourName
            // 
            this.txtYourName.Location = new System.Drawing.Point(124, 23);
            this.txtYourName.Name = "txtYourName";
            this.txtYourName.Size = new System.Drawing.Size(100, 20);
            this.txtYourName.TabIndex = 8;
            // 
            // txtHeight1
            // 
            this.txtHeight1.Location = new System.Drawing.Point(124, 57);
            this.txtHeight1.Name = "txtHeight1";
            this.txtHeight1.Size = new System.Drawing.Size(100, 20);
            this.txtHeight1.TabIndex = 9;
            // 
            // txtWeight
            // 
            this.txtWeight.Location = new System.Drawing.Point(124, 90);
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Size = new System.Drawing.Size(100, 20);
            this.txtWeight.TabIndex = 10;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rBtnImperial);
            this.groupBox1.Controls.Add(this.rBtnMetric);
            this.groupBox1.Location = new System.Drawing.Point(365, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(157, 100);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Unit";
            // 
            // rBtnImperial
            // 
            this.rBtnImperial.AutoSize = true;
            this.rBtnImperial.Location = new System.Drawing.Point(23, 76);
            this.rBtnImperial.Name = "rBtnImperial";
            this.rBtnImperial.Size = new System.Drawing.Size(116, 17);
            this.rBtnImperial.TabIndex = 1;
            this.rBtnImperial.TabStop = true;
            this.rBtnImperial.Text = "Imperial ( feet,  lbs )";
            this.rBtnImperial.UseVisualStyleBackColor = true;
            this.rBtnImperial.CheckedChanged += new System.EventHandler(this.rBtnImperial_CheckedChanged);
            // 
            // rBtnMetric
            // 
            this.rBtnMetric.AutoSize = true;
            this.rBtnMetric.Checked = true;
            this.rBtnMetric.Location = new System.Drawing.Point(23, 34);
            this.rBtnMetric.Name = "rBtnMetric";
            this.rBtnMetric.Size = new System.Drawing.Size(98, 17);
            this.rBtnMetric.TabIndex = 0;
            this.rBtnMetric.TabStop = true;
            this.rBtnMetric.Text = "Metric ( m,  kg )";
            this.rBtnMetric.UseVisualStyleBackColor = true;
            this.rBtnMetric.CheckedChanged += new System.EventHandler(this.rBtnMetric_CheckedChanged);
            // 
            // gBoxResult
            // 
            this.gBoxResult.Controls.Add(this.lblWeightinfo);
            this.gBoxResult.Controls.Add(this.lblBMIinfo);
            this.gBoxResult.Controls.Add(this.label4);
            this.gBoxResult.Controls.Add(this.label5);
            this.gBoxResult.Controls.Add(this.lblBMI);
            this.gBoxResult.Controls.Add(this.lblWeightclass);
            this.gBoxResult.Location = new System.Drawing.Point(41, 230);
            this.gBoxResult.Name = "gBoxResult";
            this.gBoxResult.Size = new System.Drawing.Size(481, 168);
            this.gBoxResult.TabIndex = 12;
            this.gBoxResult.TabStop = false;
            this.gBoxResult.Text = "Result";
            // 
            // lblWeightinfo
            // 
            this.lblWeightinfo.AutoSize = true;
            this.lblWeightinfo.Location = new System.Drawing.Point(18, 139);
            this.lblWeightinfo.Name = "lblWeightinfo";
            this.lblWeightinfo.Size = new System.Drawing.Size(62, 13);
            this.lblWeightinfo.TabIndex = 9;
            this.lblWeightinfo.Text = "Weight Info";
            // 
            // lblBMIinfo
            // 
            this.lblBMIinfo.AutoSize = true;
            this.lblBMIinfo.Location = new System.Drawing.Point(18, 108);
            this.lblBMIinfo.Name = "lblBMIinfo";
            this.lblBMIinfo.Size = new System.Drawing.Size(47, 13);
            this.lblBMIinfo.TabIndex = 8;
            this.lblBMIinfo.Text = "BMI Info";
            // 
            // txtHeight2
            // 
            this.txtHeight2.Location = new System.Drawing.Point(230, 57);
            this.txtHeight2.Name = "txtHeight2";
            this.txtHeight2.Size = new System.Drawing.Size(100, 20);
            this.txtHeight2.TabIndex = 13;
            this.txtHeight2.Visible = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(550, 420);
            this.Controls.Add(this.txtHeight2);
            this.Controls.Add(this.gBoxResult);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtWeight);
            this.Controls.Add(this.txtHeight1);
            this.Controls.Add(this.txtYourName);
            this.Controls.Add(this.lblWeight);
            this.Controls.Add(this.lblHeight);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCalculate);
            this.Name = "MainForm";
            this.Text = "Main Form";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gBoxResult.ResumeLayout(false);
            this.gBoxResult.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.Label lblWeight;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblBMI;
        private System.Windows.Forms.Label lblWeightclass;
        private System.Windows.Forms.TextBox txtYourName;
        private System.Windows.Forms.TextBox txtHeight1;
        private System.Windows.Forms.TextBox txtWeight;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rBtnImperial;
        private System.Windows.Forms.RadioButton rBtnMetric;
        private System.Windows.Forms.GroupBox gBoxResult;
        private System.Windows.Forms.TextBox txtHeight2;
        private System.Windows.Forms.Label lblWeightinfo;
        private System.Windows.Forms.Label lblBMIinfo;
    }
}

