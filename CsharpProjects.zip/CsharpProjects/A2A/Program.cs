﻿using System;

namespace A2A
{
    class selectionAndIteration
    {
        static void Main(string[] args)
        {
            Console.WriteLine();
            Console.WriteLine("My name is: Hampus I am a student of the VT21 semester"); //semester hade varigt trevligt.
            Console.WriteLine();

            //call method to calculate string length
            showStringLength();
            Console.WriteLine();

            //call method "daypredict"?
            makeMyDay();
            Console.WriteLine();

            //call method adition
            sumNumbers();

             void showStringLength() 
            {//setup
                string text = string.Empty;
                bool done = false;

                Console.WriteLine("Let me calculate length of a string for you!");
                do
                {
                    Console.WriteLine("Give me a text of any length, or press Enter to Exit!\n");
                    text = Console.ReadLine();    //input
                    int length = text.Length;     //calculate string length
                    if (length == 0)//end method
                    {
                        done = true;
                    }
                    else//continue
                    {
                        text = text.ToUpper();//convert to uppercase
                        Console.WriteLine();
                        Console.WriteLine(text);//display text in upper case
                        Console.WriteLine("The text contains " + length + " character!");//display length
                        Console.WriteLine();
                    }


                } while (!done);//if done=true method completed
            }
             void makeMyDay()
            {   //setup
                int day = 0;
                bool done = false;
                string dayy = String.Empty;
                Console.WriteLine("Let me predict your day!");
                do 
                {
                    Console.WriteLine(" Please enter a number 1-7. 1=Monday...or something else to Exit");
                    dayy = Console.ReadLine(); //input
                    bool goodNumber = int.TryParse(dayy, out day);//convert to number
                    if (goodNumber == true)//continue
                    {
                        if (day==1) //Monday
                        {
                            Console.WriteLine("It is a Monday but I am sure you can get through it!");
                            Console.WriteLine();
                        }
                        if (day==2) //Tuesday 
                        {
                            Console.WriteLine("It is not quite as bad as a Monday");
                            Console.WriteLine();
                        }
                        if (day==3)//Wednesday 
                        {
                            Console.WriteLine("It is lile Lördag! Go treat yourself!");
                            Console.WriteLine();
                        }
                        if (day==4)//Thursday 
                        {
                            Console.WriteLine("We are almost there.");
                            Console.WriteLine();
                        }
                        if (day==5)//Friday 
                        {
                            Console.WriteLine("It is Friday! Friday!");
                            Console.WriteLine();
                        }
                        if (day==6)//Saturday 
                        {
                            Console.WriteLine("It is the best day of the week!");
                            Console.WriteLine();
                        }
                        if (day == 7)//Sunday 
                        {
                            Console.WriteLine("It is a day of you can not enjoy because the next day is Monday");
                            Console.WriteLine();
                        }
                        if(day<1||day>7) //end
                        {
                            done = true;
                        }
                    }
                    else //end
                    {
                        done = true;
                    }

                } while (!done);//if done=true method completed

             }
            void sumNumbers() 
            {
                int start = 0;//setup
                int end = 0;
                int work = 0;
                string startt = string.Empty;
                string endd = string.Empty;
                bool done = false;
                do
                {
                    Console.WriteLine("Please let me sum all the numbers between two given numbers"); //input1
                    Console.WriteLine("Please enter the first number");
                    startt = Console.ReadLine();
                    Console.WriteLine("Please enter the second number"); //input2
                    endd = Console.ReadLine();

                    bool goodnr1 = int.TryParse(startt, out start);//check input 1
                    if (goodnr1 == true)//continue
                    {
                        bool goodnr2 = int.TryParse(endd, out end);
                        if (goodnr2 == true)//continue
                        {
                            if (end == start)
                            {
                                Console.WriteLine("The sum is "+start);//complete
                            }
                            else //continue
                            {
                                if (end < start) //bacwards
                                {
                                    do 
                                    {
                                        work = work + end;
                                        end++;
                                    } while (end!=start);
                                    work = work + end;
                                    Console.WriteLine("The sum is "+work);
                                    work = 0;//reset work
                                }
                                else//normal 
                                {
                                    do 
                                    {
                                        work = work + start;
                                        start++;
                                    } while (start!=end);
                                    work = work + start;
                                    Console.WriteLine("The sum is "+work);
                                    work = 0;//reset work
                                }
                            }
                        }
                        else //end
                        {
                            done = true;
                        }
                    }
                    else //end
                    {
                        done = true;
                    }
                } while (!done);//if done=true method completed
            }
        }
    }
}
