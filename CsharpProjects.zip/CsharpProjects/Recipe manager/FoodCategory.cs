﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipe_manager
{
    enum FoodCategories 
    {
        Meat,
        Pasta,
        Pizza,
        Fish,
        Seafood,
        Soups,
        Stew,
        Vegan,
        Vegeterian,
        Vegeterian_Dairy_Egg,
        Other
    }
}
