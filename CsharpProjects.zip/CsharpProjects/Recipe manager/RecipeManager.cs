﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipe_manager
{
    public class RecipeManager
    ///<summary>
    ///the job of this class is to create and maintain a list of all the recipes calling input from MainForm and  the Recipe class
    ///this class will be called by the mainform to display the list of recipes
    ///<summary>
    {
        ///a recipe consists of a list of ingredients (the recipe class) a category assigned by user input on the main form and a description also
        ///provided by the MainForm 
        private Recipe[] recipeList;

        public RecipeManager(int MaxNumOfElements)
        {
            recipeList = new Recipe[MaxNumOfElements];

            
        }
    



        //getters and setters
        public Recipe GetRecipe() 
        {

        }
        public void SetRecipe() 
        { 
        
        }
        public FoodCategories GetFoodCategory() 
        {

        }
        public void SetFoodCategory(FoodCategories value) 
        {
            
        }
        public void GetDescription() 
        { 
        
        }
        public void SetDescription() 
        { 
        
        }
    }
}
