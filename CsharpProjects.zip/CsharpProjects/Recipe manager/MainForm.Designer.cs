﻿
namespace Recipe_manager
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAddIngredient = new System.Windows.Forms.Button();
            this.btnAddRecipe = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnEditFinish = new System.Windows.Forms.Button();
            this.btnEditStart = new System.Windows.Forms.Button();
            this.cmbFoodCategory = new System.Windows.Forms.ComboBox();
            this.grpAddRecipe = new System.Windows.Forms.GroupBox();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.txtNameRecipe = new System.Windows.Forms.TextBox();
            this.lblNameRecipe = new System.Windows.Forms.Label();
            this.lblCategory = new System.Windows.Forms.Label();
            this.lblListCategory = new System.Windows.Forms.Label();
            this.lblNumIngredients = new System.Windows.Forms.Label();
            this.lblListRecipe = new System.Windows.Forms.Label();
            this.lstRecipe = new System.Windows.Forms.ListBox();
            this.grpAddRecipe.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAddIngredient
            // 
            this.btnAddIngredient.Location = new System.Drawing.Point(216, 79);
            this.btnAddIngredient.Name = "btnAddIngredient";
            this.btnAddIngredient.Size = new System.Drawing.Size(101, 23);
            this.btnAddIngredient.TabIndex = 0;
            this.btnAddIngredient.Text = "Add_Ingredient";
            this.btnAddIngredient.UseVisualStyleBackColor = true;
            this.btnAddIngredient.Click += new System.EventHandler(this.btnAddIngredient_Click);
            // 
            // btnAddRecipe
            // 
            this.btnAddRecipe.Location = new System.Drawing.Point(73, 351);
            this.btnAddRecipe.Name = "btnAddRecipe";
            this.btnAddRecipe.Size = new System.Drawing.Size(177, 23);
            this.btnAddRecipe.TabIndex = 1;
            this.btnAddRecipe.Text = "Add_Recipe";
            this.btnAddRecipe.UseVisualStyleBackColor = true;
            this.btnAddRecipe.Click += new System.EventHandler(this.btnAddRecipe_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(706, 334);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 2;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(625, 334);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnEditFinish
            // 
            this.btnEditFinish.Location = new System.Drawing.Point(544, 334);
            this.btnEditFinish.Name = "btnEditFinish";
            this.btnEditFinish.Size = new System.Drawing.Size(75, 23);
            this.btnEditFinish.TabIndex = 4;
            this.btnEditFinish.Text = "Edit_Finish";
            this.btnEditFinish.UseVisualStyleBackColor = true;
            this.btnEditFinish.Click += new System.EventHandler(this.btnEditFinish_Click);
            // 
            // btnEditStart
            // 
            this.btnEditStart.Location = new System.Drawing.Point(463, 334);
            this.btnEditStart.Name = "btnEditStart";
            this.btnEditStart.Size = new System.Drawing.Size(75, 23);
            this.btnEditStart.TabIndex = 5;
            this.btnEditStart.Text = "Edit_Start";
            this.btnEditStart.UseVisualStyleBackColor = true;
            this.btnEditStart.Click += new System.EventHandler(this.btnEditStart_Click);
            // 
            // cmbFoodCategory
            // 
            this.cmbFoodCategory.FormattingEnabled = true;
            this.cmbFoodCategory.Location = new System.Drawing.Point(73, 79);
            this.cmbFoodCategory.Name = "cmbFoodCategory";
            this.cmbFoodCategory.Size = new System.Drawing.Size(121, 21);
            this.cmbFoodCategory.TabIndex = 6;
            // 
            // grpAddRecipe
            // 
            this.grpAddRecipe.Controls.Add(this.txtDescription);
            this.grpAddRecipe.Controls.Add(this.txtNameRecipe);
            this.grpAddRecipe.Controls.Add(this.lblNameRecipe);
            this.grpAddRecipe.Controls.Add(this.lblCategory);
            this.grpAddRecipe.Controls.Add(this.btnAddRecipe);
            this.grpAddRecipe.Controls.Add(this.cmbFoodCategory);
            this.grpAddRecipe.Controls.Add(this.btnAddIngredient);
            this.grpAddRecipe.Location = new System.Drawing.Point(12, 12);
            this.grpAddRecipe.Name = "grpAddRecipe";
            this.grpAddRecipe.Size = new System.Drawing.Size(323, 403);
            this.grpAddRecipe.TabIndex = 7;
            this.grpAddRecipe.TabStop = false;
            this.grpAddRecipe.Text = "Add Recipe";
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(9, 128);
            this.txtDescription.MinimumSize = new System.Drawing.Size(250, 200);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(292, 217);
            this.txtDescription.TabIndex = 14;
            // 
            // txtNameRecipe
            // 
            this.txtNameRecipe.Location = new System.Drawing.Point(94, 48);
            this.txtNameRecipe.Name = "txtNameRecipe";
            this.txtNameRecipe.Size = new System.Drawing.Size(100, 20);
            this.txtNameRecipe.TabIndex = 15;
            this.txtNameRecipe.Text = "Name Recipe";
            // 
            // lblNameRecipe
            // 
            this.lblNameRecipe.AutoSize = true;
            this.lblNameRecipe.Location = new System.Drawing.Point(6, 51);
            this.lblNameRecipe.Name = "lblNameRecipe";
            this.lblNameRecipe.Size = new System.Drawing.Size(72, 13);
            this.lblNameRecipe.TabIndex = 12;
            this.lblNameRecipe.Text = "Name Recipe";
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Location = new System.Drawing.Point(6, 87);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(49, 13);
            this.lblCategory.TabIndex = 8;
            this.lblCategory.Text = "Category";
            // 
            // lblListCategory
            // 
            this.lblListCategory.AutoSize = true;
            this.lblListCategory.Location = new System.Drawing.Point(542, 12);
            this.lblListCategory.Name = "lblListCategory";
            this.lblListCategory.Size = new System.Drawing.Size(68, 13);
            this.lblListCategory.TabIndex = 9;
            this.lblListCategory.Text = "List Category";
            // 
            // lblNumIngredients
            // 
            this.lblNumIngredients.AutoSize = true;
            this.lblNumIngredients.Location = new System.Drawing.Point(651, 12);
            this.lblNumIngredients.Name = "lblNumIngredients";
            this.lblNumIngredients.Size = new System.Drawing.Size(130, 13);
            this.lblNumIngredients.TabIndex = 10;
            this.lblNumIngredients.Text = "List Number of Ingredients";
            // 
            // lblListRecipe
            // 
            this.lblListRecipe.AutoSize = true;
            this.lblListRecipe.Location = new System.Drawing.Point(449, 12);
            this.lblListRecipe.Name = "lblListRecipe";
            this.lblListRecipe.Size = new System.Drawing.Size(60, 13);
            this.lblListRecipe.TabIndex = 11;
            this.lblListRecipe.Text = "List Recipe";
            // 
            // lstRecipe
            // 
            this.lstRecipe.FormattingEnabled = true;
            this.lstRecipe.Location = new System.Drawing.Point(452, 38);
            this.lstRecipe.Name = "lstRecipe";
            this.lstRecipe.Size = new System.Drawing.Size(329, 264);
            this.lstRecipe.TabIndex = 13;
            this.lstRecipe.SelectedIndexChanged += new System.EventHandler(this.lstRecipe_SelectedIndexChanged);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lstRecipe);
            this.Controls.Add(this.lblListRecipe);
            this.Controls.Add(this.lblNumIngredients);
            this.Controls.Add(this.lblListCategory);
            this.Controls.Add(this.grpAddRecipe);
            this.Controls.Add(this.btnEditStart);
            this.Controls.Add(this.btnEditFinish);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClear);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.grpAddRecipe.ResumeLayout(false);
            this.grpAddRecipe.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAddIngredient;
        private System.Windows.Forms.Button btnAddRecipe;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnEditFinish;
        private System.Windows.Forms.Button btnEditStart;
        private System.Windows.Forms.ComboBox cmbFoodCategory;
        private System.Windows.Forms.GroupBox grpAddRecipe;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.Label lblListCategory;
        private System.Windows.Forms.Label lblNumIngredients;
        private System.Windows.Forms.Label lblListRecipe;
        private System.Windows.Forms.Label lblNameRecipe;
        private System.Windows.Forms.ListBox lstRecipe;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.TextBox txtNameRecipe;
    }
}

