﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Recipe_manager
{
    public partial class FormIngredients : Form
    {
        private Recipe recipe = new Recipe();
        public FormIngredients()
        {
            InitializeComponent();
            InitializeGUI();
        }

        private void InitializeGUI() 
        { 
         
        }

        private void UpdateGUI() 
        {
            
        }

        FormIngredients(Recipe recipe) 
        {
            
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {

        }
    }
}
