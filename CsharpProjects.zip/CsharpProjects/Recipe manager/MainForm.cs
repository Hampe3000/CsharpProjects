﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Recipe_manager
{
    public partial class MainForm : Form
    {
        const int maxNumOfElements = 200;
        const int maxNumOfIngredients = 50;

        private Recipe currRecipe = new Recipe(maxNumOfIngredients);//Creates s new recipe for the application to work with
        private RecipeManager recipeMngr = new RecipeManager(maxNumOfElements); //Creates new instance of the recipe manager

        public MainForm()
        {
            InitializeComponent();
            InitializeGUI();
        }
        private void InitializeGUI()
        {
          Text = "Cook Book"; //changes the name of the application window
          txtNameRecipe.Text = string.Empty;
          
        }
        private void UpdateGUI()
        {

        }
        private void btnAddIngredient_Click(object sender, EventArgs e)
        {
            FormIngredients dlg = new FormIngredients();
            DialogResult dlgResult = dlg.ShowDialog();

            if (dlgResult == DialogResult.OK)
            {
                if (currRecipe.CurrentNumberOfIngredients() <= 0)
                {
                    //TODO messagevox
                    MessageBox.Show("No ingredients specified", "Error");
                }
            }
        }

        private void btnAddRecipe_Click(object sender, EventArgs e)
        {
            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

        }

        private void btnEditStart_Click(object sender, EventArgs e)
        {

        }

        private void btnEditFinish_Click(object sender, EventArgs e)
        {

        }

        private void lstRecipe_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lstRecipe_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }
    }
}
