﻿
namespace Recipe_manager
{
    partial class FormIngredients
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.grpIngredient = new System.Windows.Forms.GroupBox();
            this.lblCurrNumber = new System.Windows.Forms.Label();
            this.lblNumIngredients = new System.Windows.Forms.Label();
            this.lstIngredients = new System.Windows.Forms.ListBox();
            this.txtNameIngredient = new System.Windows.Forms.TextBox();
            this.grpIngredient.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(200, 33);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(173, 356);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(200, 91);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 2;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(200, 62);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(75, 23);
            this.btnEdit.TabIndex = 3;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(62, 356);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 4;
            this.btnOk.Text = "Ok";
            this.btnOk.UseVisualStyleBackColor = true;
            // 
            // grpIngredient
            // 
            this.grpIngredient.Controls.Add(this.lstIngredients);
            this.grpIngredient.Controls.Add(this.txtNameIngredient);
            this.grpIngredient.Controls.Add(this.btnAdd);
            this.grpIngredient.Controls.Add(this.btnEdit);
            this.grpIngredient.Controls.Add(this.btnDelete);
            this.grpIngredient.Location = new System.Drawing.Point(18, 40);
            this.grpIngredient.Name = "grpIngredient";
            this.grpIngredient.Size = new System.Drawing.Size(293, 310);
            this.grpIngredient.TabIndex = 5;
            this.grpIngredient.TabStop = false;
            this.grpIngredient.Text = "Ingredient";
            // 
            // lblCurrNumber
            // 
            this.lblCurrNumber.AutoSize = true;
            this.lblCurrNumber.Location = new System.Drawing.Point(248, 9);
            this.lblCurrNumber.Name = "lblCurrNumber";
            this.lblCurrNumber.Size = new System.Drawing.Size(63, 13);
            this.lblCurrNumber.TabIndex = 6;
            this.lblCurrNumber.Text = "CurrNumber";
            // 
            // lblNumIngredients
            // 
            this.lblNumIngredients.AutoSize = true;
            this.lblNumIngredients.Location = new System.Drawing.Point(15, 9);
            this.lblNumIngredients.Name = "lblNumIngredients";
            this.lblNumIngredients.Size = new System.Drawing.Size(81, 13);
            this.lblNumIngredients.TabIndex = 7;
            this.lblNumIngredients.Text = "NumIngredients";
            // 
            // lstIngredients
            // 
            this.lstIngredients.FormattingEnabled = true;
            this.lstIngredients.Location = new System.Drawing.Point(6, 80);
            this.lstIngredients.Name = "lstIngredients";
            this.lstIngredients.Size = new System.Drawing.Size(188, 212);
            this.lstIngredients.TabIndex = 8;
            // 
            // txtNameIngredient
            // 
            this.txtNameIngredient.Location = new System.Drawing.Point(6, 33);
            this.txtNameIngredient.Name = "txtNameIngredient";
            this.txtNameIngredient.Size = new System.Drawing.Size(188, 20);
            this.txtNameIngredient.TabIndex = 9;
            this.txtNameIngredient.Text = "Name Ingredient";
            // 
            // FormIngredients
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(340, 397);
            this.Controls.Add(this.lblNumIngredients);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.lblCurrNumber);
            this.Controls.Add(this.grpIngredient);
            this.Controls.Add(this.btnOk);
            this.Name = "FormIngredients";
            this.Text = "FormIngredients";
            this.grpIngredient.ResumeLayout(false);
            this.grpIngredient.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.GroupBox grpIngredient;
        private System.Windows.Forms.Label lblCurrNumber;
        private System.Windows.Forms.Label lblNumIngredients;
        private System.Windows.Forms.ListBox lstIngredients;
        private System.Windows.Forms.TextBox txtNameIngredient;
    }
}